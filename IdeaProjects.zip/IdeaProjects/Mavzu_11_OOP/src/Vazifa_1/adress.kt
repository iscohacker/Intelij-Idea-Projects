package Vazifa_1

class Adress {
    var street : String = "Kulas Light"
    var suite  : String = "Apt .556"
    var city  : String = "Gvenbrought"
    var zipcpde  : String = "92998-3874"
    var geo : Geo = Geo()
}