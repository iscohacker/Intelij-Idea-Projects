package Vazifa_1

fun main() {
    val user = User()
    println(user.name)
    println(user.address.geo.lat)
    println(user.company.name)
}