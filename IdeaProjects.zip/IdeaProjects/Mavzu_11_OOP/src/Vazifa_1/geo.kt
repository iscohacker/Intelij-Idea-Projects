package Vazifa_1

class Geo {
    var lat : String = "-37.3159"
    var lng : String = "81.1496"
}