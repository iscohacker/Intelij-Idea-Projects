package Vazifa_1

class Company {
    var name : String = "Isco Coder"
}