package Vazifa_1

class User(){
    var id: Int = 1
    var name : String= "Iskandarbek"
    var username : String = "Breat"
    var email : String = "iscoitcoder@gmail.com"
    var address : Adress = Adress()
    var phone : String = "+998907762036"
    var weebsite : String = "isco.uz"
    val company = Company()
}