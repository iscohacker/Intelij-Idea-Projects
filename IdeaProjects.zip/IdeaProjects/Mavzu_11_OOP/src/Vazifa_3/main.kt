package Vazifa_3


fun main() {
    val workers = ArrayList<Worker>()
    workers.add(Worker("Nosirov", "Iskandbek", 56, "Direktor", 2022))
    workers.add(Worker("Nosirov", "Iskandbek", 17, "Direktor", 2022))
    workers.add(Worker("Nosirov", "Iskandbek", 45, "Direktor", 2022))
    workers.add(Worker("Nosirov", "Iskandbek", 43, "Direktor", 2022))
    workers.add(Worker("Nosirov", "Iskandbek", 17, "Direktor", 2022))
    workers.add(Worker("Nosirov", "Iskandbek", 17, "Direktor", 2022))

    for (i in workers.indices){
        if (workers[i].yoshi>30){
            println("${workers[i].ismi} ${workers[i].familiya} ${workers[i].yoshi} ${workers[i].lavozimi} ${workers[i].ishgaKirganYili}")
        }
    }
}
