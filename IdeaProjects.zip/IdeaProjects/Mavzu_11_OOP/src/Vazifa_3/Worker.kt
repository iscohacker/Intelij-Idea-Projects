package Vazifa_3
class Worker(
    val ismi: String,
    val familiya: String,
    val yoshi: Int,
    val lavozimi: String,
    val ishgaKirganYili: Int
)