package Vazifa_4

fun main() {
    val sut=Price()
    sut.mahsulotNomi="Sut"
    sut.dokon="Oziq ovqat dokoni"
    sut.narhi=14000

    val lavash=Price()
    lavash.mahsulotNomi="Lavash"
    lavash.dokon="Oqtepa lavash"
    lavash.narhi=30000

    val non=Price()
    non.mahsulotNomi="Non"
    non.dokon="Novvoy hona"
    non.narhi=2500

    val burger=Price()
    burger.mahsulotNomi="Non Burger"
    burger.dokon="Fast Food dohoni"
    burger.narhi=16000

    val osh=Price()
    osh.mahsulotNomi="Osh"
    osh.dokon="Choy hona"
    osh.narhi=150000

    val mahsulotlar= arrayOf(sut,lavash,non,burger,osh)
    for (price in mahsulotlar) {
        if (price.narhi!!>10000){
            println(price.narhi)
        }
    }
}//nosirov