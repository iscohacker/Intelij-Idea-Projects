package Vazifa_4
class Price {
    var mahsulotNomi:String?=null
    var dokon:String?=null
    var narhi:Int?=null
    override fun toString(): String {
        return "Price(mahsulotNomi=$mahsulotNomi, dokon=$dokon, narhi=$narhi)"
    }
}
//nosirov