package Vazifa_2

class Order {
        var ism: String? = null
        var vazni: Double? = null
        var boyi: Int? = null

        fun dasturchi() {
            println("$ism Zor dasturchi")
        }
    }