package Vazifa_2

fun main(args:Array<String>) {

    val isco : Order = Order()
    isco.ism = "Iskandarbek"
    isco.boyi = 170
    isco.vazni = 55.0
    isco.dasturchi()

    val isco1  = Order()
    isco1.ism = "Nosirov"
    isco1.boyi = 180
    isco1.vazni = 70.0
    isco1.dasturchi()

    val isco2 = Order()
    isco2.ism = "Ilmiddin"
    isco2.boyi = 150
    isco2.vazni = 65.0
    isco2.dasturchi()

    val isco3 = Order()
    isco3.ism = "O'rinov"
    isco3.boyi = 170
    isco3.vazni = 55.0
    isco3.dasturchi()

    val isco4 = Order()
    isco4.ism = "Iskandarbek"
    isco4.boyi = 190
    isco4.vazni = 55.0
    isco4.dasturchi()


}