package Vazifa_5
class Metro {
    var jonash:String?=null
    var bekat:String?=null
    var yoldaYurishVaqti:Int?=null
    var liniyaRaqam:Int?=null
}