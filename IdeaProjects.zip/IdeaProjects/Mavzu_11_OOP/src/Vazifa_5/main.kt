package Vazifa_5

fun main() {
    val a:Metro=Metro()
    a.jonash="Fargona"
    a.bekat="Toshkent"
    a.liniyaRaqam=1
    a.yoldaYurishVaqti=2

    val b:Metro=Metro()
    b.jonash="Toshkent"
    b.bekat="Fargona"
    b.liniyaRaqam=2
    b.yoldaYurishVaqti=2

    val c:Metro=Metro()
    c.jonash="Namangan"
    c.bekat="Fargona"
    c.liniyaRaqam=6
    c.yoldaYurishVaqti=1

    val d:Metro=Metro()
    d.jonash="Qoraqalpoqiston"
    d.bekat="Fargona"
    d.liniyaRaqam=9
    d.yoldaYurishVaqti=6

    val f:Metro=Metro()
    f.jonash="Fargona"
    f.bekat="Samarqant"
    f.liniyaRaqam=5
    f.yoldaYurishVaqti=3

    val mtr= arrayOf(a,b,c,d,f)
    for (metro in mtr) {
        if (metro.yoldaYurishVaqti!!<5)
            println(metro.yoldaYurishVaqti)
    }
}