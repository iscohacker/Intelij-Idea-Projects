//fun main() {
//    val android = Oqim1()
//    val web = Oqim2()
//    val grapihics = Oqim3()
//    android.start()
//    web.start()
//    grapihics.start()
//}
//
//class Oqim1 : Thread() {
//    override fun run() {
//        super.run()
//        while (true) {
//            println("Android Developer")
//            sleep(1000)
//        }
//    }
//}
//
//class Oqim2 : Thread() {
//    override fun run() {
//        super.run()
//        while (true) {
//            println("Web Developer")
//            sleep(1000)
//        }
//    }
//}
//
//class Oqim3 : Thread() {
//    override fun run() {
//        super.run()
//        while (true) {
//            println("Grapihics Developer")
//            sleep(1000)
//        }
//    }
//}


fun main() {
    val android = Oqim1()
    val backend = Oqim2()

    val android1 = Thread(android)
    android1.start()
    val backend1 = Thread(backend)
    backend1.start()
}

class Oqim1 : Runnable{
    override fun run() {
        while (true){
            println("Android Developer")
            Thread.sleep(1000)
        }
    }

}class Oqim2 : Runnable{
    override fun run() {
        while (true){
            println("Backend Developer")
            Thread.sleep(1000)
        }
    }

}