package Dictonary1
import java.util.*
import kotlin.collections.ArrayList

fun main() {
    val input = Scanner(System.`in`)
    val listUZB = ArrayList<String>()
    val listENG = ArrayList<String>()
    while (true) {
        println(
            "1->Qo'shish\n" +
                    "2->Ko'rish\n" +
                    "3->O'chirish"
        )
        var kirit = input.nextInt()
        when (kirit) {
            1 -> {
                print("UZB->")
                val name = input.next()
                print("ENG->")
                val name1 = input.next()
                listUZB.add(name)
                listENG.add(name1)
                println("Kiritilgan ma'lumotlar saqlandi!")
            }
            2 -> {
                if (listUZB.isNotEmpty() && listENG.isNotEmpty()) {
                    for (i in 0 until listUZB.size) {
                        println("$i.${listUZB[i]} -> ${listENG[i]}")
                    }
                } else {
                    println("Ro'yxat bo'sh! Ma'lumotlar kiritilganini tekshiring")
                }
            }
            3->{
                if (listUZB.isNotEmpty() && listENG.isNotEmpty()) {
                    for (i in 0 until listUZB.size) {
                        println("$i.${listUZB[i]} -> ${listENG[i]}")
                    }
                } else {
                    println("Ro'yxat bo'sh! Ma'lumotlar kiritilganini tekshiring!")
                }
                print("Iltimos o'chirmoqchi bo'lgan ekement indeksini kiriting: ")
                var ochir = input.nextInt()
                listUZB.remove(listUZB[ochir])
                listENG.remove(listENG[ochir])
                println("Ma'lumotlar o'chirib yuborildi.")
            }

        }
    }
}