package Dictonary2

import java.util.*

fun main() {
    val uzbList = arrayOfNulls<String>(100)
    val engList = arrayOfNulls<String>(100)
    var input = Scanner(System.`in`)
    var sanoq = 0

    while(true){
        println("1->So'z qo'shish\n" +
                "2->Ko'rish\n" +
                "3->O'chirish\n" +
                "4->Tahrirlash\n" +
                "5->Qidirish")
        var n = input.nextInt()
        when(n){
            1->{
                print("O'zbekcha so'z kiriting: ")
                var uzb = input.next()
                print("Inglizcha so'z kiriting: ")
                var eng = input.next()
                uzbList[sanoq] = uzb
                engList[sanoq] = eng
                sanoq++
                println("Kiritilgan ma'lumotlar saqlandi!")


            }
            2->{
                for (i in 0 until sanoq){
                    println("UZB: ${uzbList[i]} " +
                            "ENG: ${engList[i]}")
                }

            }
            3->{
                println("Qaysi indeksdagi ma'lumotni o'chirmoqchisiz: ")
                for (i in 0 until sanoq){
                    println("UZB: $i ${uzbList[i]} " +
                            "ENG: ${engList[i]}")

                }
                var index = input.nextInt()
                for (i in index until sanoq){
                    uzbList[i] = uzbList[i+1]
                    engList[i] = engList[i+1]
                }
                sanoq--
                println("Ma'lumotlar o'chirib yuborildi!")

            }
            4->{
                println("Qaysi elementi tahrirlamoqchisiz: ")
                for (i in 0 until sanoq){
                    println("UZB: $i ${uzbList[i]} " +
                            "ENG: ${engList[i]}")
                }
                var index = input.nextInt()
                println("Yangi o'zbekcha so'z kiriting: ")
                uzbList[index] = input.next()
                println("Yangi ibglizcha so'z kiriting: ")
                engList[index] = input.next()
                println("Ma'lumotlar tahrirlandi!")

            }
            5->{
                println("Qidirmoqchi bo'lgan elementingizni kiriting: ")
                var searchWord = input.next()
                for (i in 0 until sanoq){
                    if (uzbList[i]!!.lowercase().contains(searchWord) || engList[i]!!.lowercase().contains(searchWord)){
                        println("${uzbList[i]},${engList[i]}")
                    }
                }
            }
        }
    }
}