interface MyServiceInterface {
    fun addWord()
    fun showWord()
    fun editWord()
    fun deletWord()
}