class Words {
    var englishword: String? = null
    var uzbekword: String? = null

    constructor(engword: String, uzword: String?) {
        this.englishword = engword
        this.uzbekword = uzword
    }

    override fun toString(): String {
        return "Words(engWord=${englishword} , uzWord=${uzbekword} )"
    }

}