import java.util.*
import kotlin.system.exitProcess

fun main() {
    val input = Scanner(System.`in`)

    val myService = MyService()

    while (true) {
        if (myService.sanoq == 0) {
            println(
                "Hali dasturga birorta ham lug'at qoshilmadi \n" +
                        "Lug'at qo'shish uchun 1 ni bosing\n" +
                        "Dasturdan chiqish uchun esa 0 ni bosing"
            )
            when (input.nextInt()) {
                1 -> myService.addWord()
                0 -> exitProcess(0)
            }
        }

            println(
                        " 1-> So'z qo'shish\n" +
                        " 2-> So'zlarni ko'rish\n" +
                        " 3-> So'zlarni o'chirish\n" +
                        " 4-> So'zlarni tahrirlash"
            )
            when (input.nextInt()) {
                1 -> myService.addWord()
                2 -> myService.showWord()
                3 -> myService.deletWord()
                4 -> myService.editWord()
            }
        }
    }