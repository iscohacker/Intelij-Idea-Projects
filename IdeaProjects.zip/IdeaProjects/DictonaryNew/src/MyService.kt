import java.util.*

class MyService : MyServiceInterface {
    var list = arrayOfNulls<Words>(100)
    var input = Scanner(System.`in`)
    var sanoq = 0
    override fun addWord() {
        println("Iltmos , uzbekcha so'z kiriting: ")
        val uzWord = input.next()
        println("Iltimos , inglizcha so'z kiriting: ")
        val engWord = input.next()
        val words = Words(engWord, uzWord)
        list[sanoq] = words
        sanoq++
        println("Saqlandi!")
        println(" ")
    }

    override fun showWord() {
        if (sanoq == 0) {
            println("Bo'limda soz yo'q️")
            println("")
        }
        for (i in 0 until sanoq) {
            println(list[i])
        }
    }


    override fun deletWord() {
        println(" Iltimos , o'chirmoqchi bo'lgan so'zlar raqamini tanlang: ")
        for (i in 0 until sanoq) {
            println("$i -> ${list[i]} ")
        }
        val index = input.nextInt()
        for (i in index until sanoq) {
            list[i] = list[i + 1]
            println("")
        }
        sanoq--
        println("So'zlar ochirildi")
        println("")
    }

    override fun editWord() {
        println("Iltimos , tahrirlamoqchi bo'lgan so'zlar  raqamini kiriting: ")
        for (i in 0 until sanoq) {
            println("$i -> ${list[i]}")
            println(" ")
        }
        val index = input.nextInt()
        println("Iltimos , yangi uzbekcha so'z kiriting: ")
        val newUz = input.next()
        println("Iltimos , yangi inglizcha so'z kiriting: ")
        val engnew = input.next()
        list[index] = Words(newUz,engnew)
        println("Tahrirlandi")
    }
}
