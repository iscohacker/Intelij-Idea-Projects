package MasterClass1

fun main() {

}