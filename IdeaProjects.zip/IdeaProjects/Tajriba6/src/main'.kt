import tushuncha.MyServiceInterface
import java.util.*


//
////fun main() {
////    var i = 0
////    while (i<100){
////        println("Iskandarbek")
////        i++
////    }
//////}
//


////IKKINCHI AMALIYOT
////fun main() {
////    var i = 0
////    while (i<=100){
////        println(i)
////        i++
////    }
////}
//
//



////fun main() {
////    var i = 10
////    while (i>=0){
////        println(i)
////    i--
////}
////}
//
//


////fun main() {
////    var i = 0
////    while (i<=100){
////        println(i)
////        i+=2
////    }
////}
////



////fun main() {
////    for (i in 0..100) {
////        println(i)
////    }
////}
////


////fun main() {
////    for (i in 0..100 step 2) {
////        println(i)
////    }
////}
////


////fun main() {
////    for(i in 100 downTo 0 step 2){
////        println(i)
////    }
////}


//
////fun main() {
////    val str = "Kotlin"
////    for (i in 0 until str.length) {
////        print(str[i])
////        print(str[i])
////    }
////}
//
//


//fun main() {
//    for(i in 0 until 10){
//        if (i==5){
//            continue
//        }
//        println(i)
//    }
////}


//fun main() {
//    for (i in 0 until  10){
//        if (i==5){
//            break
//        }
//        println(i)
//    }
//}
//


//fun main() {
//    var i =0
//    while (i<10){
//        println("Basseynga kalla tashla")
//        i++
//    }
//}

//



//fun main() {
//    var suv = false
//    do {
//        println("bassenga kalla tasha ")
//    }while (suv)
//}//sharti keyin berilgan sikl operatori

//
////funksiyaaaa
//
//fun main() {
//     mening_funksiyam()
//}
//fun mening_funksiyam(){
//    println("Men ishlayabman")
//}


//fun main() {
//    muomala("Iskandarbek")
//}
//fun muomala(name:String){
//    println("Assalomu alaykum  $name")
//    println("Axvolaringiz yaxshimi $name")
//    println("Puldan muammo yo'qmi$name ")
//    println("Qanday yordam beray$name")
//
//}
//ctrl+alt+L = kalibreslarni sartirofka qilish



//fun main() {
//    muomala("Iskandarbek",17)
//    muomala("Iskandarbek",16)
//    muomala("Iskandarbek",18)
//    muomala("Iskandarbek",19)
//
//}
//
//fun muomala(name: String, age: Int) {
//    var bro = ""
//    if (age > 17) {
//        bro = "aka"
//    } else if (age < 17) {
//        bro = "uka"
//    } else {
//        bro = "birodar"
//    }
//    println("Assalomu alaykum  $name $bro")
//    println("Axvolaringiz yaxshimi $name $bro")
//    println("Puldan muammo yo'qmi$name $bro")
//    println("Qanday yordam beray$name $bro")
//}



////parametrli qiymat qaytaradigan
//fun main() {
//    println(stikerolbkel())
//}
////funnni ichidagi parametrli : ni oldiddagi qiymat qaytaradigan
//fun stikerolbkel():String{
//    return "Mana senlaga stiker"
//}




//fun main() {
//    rasmgaol()
//}
//fun rasmgaol():String{
//    println("rasmga olyapman")
//    return "mana senga rasm"
//    println("Videoga olyapman")
//
//}


////random
//fun main() {
//    val random = java.util.Random()
//    val number = random.nextInt()
//    println(number)
//}
//
//



//fun main() {
//    val random = java.util.Random()
//    val number = random.nextInt(10)
//    val number2 = random.nextInt(10)
//    val number3 = random.nextInt(10)
//    println(number)
//    println(number2)
//    println(number3)
//}




//ismlarni random qlww
//fun main() {
//    val array = arrayOf("MuhammadYusuf","MuhammadAmin","Iskandar","Xojiakbar","Diyorbek","Sardorbek","Elbek","Ilmiddin")
//    val random = java.util.Random()
//    val number = random.nextInt(8)
//    println(array[number])
//
//}
////
//import kotlin.random.Random
//fun main() {
//    random()
//}//rekursiv funksiya
//fun random(){
//    val random = java.util.Random()
//    val n1 = random.nextInt(3)
//    val n2 = random.nextInt(3)
//    val n3 = random.nextInt(3)
//    if (n1==n2 || n2==n3 || n3==n1){
//        random()
//    }else{
//        println(n1)
//        println(n2)
//        println(n3)
//    }
//}

//import kotlin.random.Random
//fun main() {
//    random()
//}//rekursiv funksiya
//fun random(){
//    val random = java.util.Random()
//    val n1 = random.nextInt(3)
//    val n2 = random.nextInt(3)
//    val n3 = random.nextInt(3)
//    if (n1==n2 || n2==n3 || n3==n1){
//        random()
//    }else{
//        println(n1)
//        println(n2)
//        println(n3)
//    }
//}





//
//fun main() {
//    val array = arrayOf("MuhammadYusuf", "MuhammadAmin", "Iskandar", "Xojiakbar", "Diyorbek", "Sardorbek", "Elbek", "Ilmiddin")
//    val random = java.util.Random()
//    val number = random.nextInt(8)
//    println(array[number])
//}


//
//fun main() {
//    isimsora("Iskandarbek")
//    yoshnisora(17)
//    familyasora("Nosirov")
//    maktabsora(8)
//    sinfsora(11)
//}
//fun isimsora(name:String){
//    println("Ismingiz: $name")
//}
//fun yoshnisora(age:Int){
//    println("Yoshingiz: $age")
//}
//fun familyasora(familya:String){
//    println("Familyangiz: $familya")
//}
//fun maktabsora(maktab:Int){
//    println("Maktabingiz: $maktab")
//}
//fun sinfsora(sinf:Int){
//    println("Sinfingiz: $sinf")
//}



//
//fun main() {
//    println(yosh())
//    println(familya())
//    println(text())
//    println(shaxar_tuman())
//}
//fun yosh():Int {
//    return 17
//}
//fun familya():String{
//    return "Nosirov"
//}
//fun text():Boolean{
//    return true
//}
//fun shaxar_tuman():Char{
//    return '?'
//}





//import java.util.Scanner
//
//fun main() {
//    val input = Scanner(System.`in`)
//    println("Iltimos, so'zni kiriting:")
//    val txt = input.nextLine()
//    val teskarisoz = txt.reversed()
//    print("Teskari so'z: ")
//    println(" $teskarisoz")
//
//    val s = "Koltin"
//    print("lt sozlari almashmasi")
//    print(s)
//
//    val boshii = txt.substring(0,txt.length-2)
//    val a = txt.substring(txt.length-2,txt.length-1)
//    val b = txt.substring(txt.length-1, txt.length)
//    print("Oxiridagi ikkita belgi almashgan so'z: ")
//    println("$boshii$b$a")
//}
//






//fun main() {
//    while (true){
//        var input = Scanner(System.`in`)
//        print("son kiriting,janob= ")
//        val son = input.nextInt()
//        println(isco(son))
//    }
//}
//fun isco(son:Int):Int {
//    val random = Random()
//    val number = random.nextInt(son)
//    if (number == 3) {
//        isco(son)
//    } else
//        return number


//import kotlin.random.Random
//fun main() {
//    random()
//}//rekursiv funksiya
//fun random(){
//    val random = java.util.Random()
//    val n1 = random.nextInt(3)
//    val n2 = random.nextInt(3)
//    val n3 = random.nextInt(3)
//    if (n1==n2 || n2==n3 || n3==n1){
//        random()
//    }else{
//        println(n1)
//        println(n2)
//        println(n3)
//    }
//}



//parametrli qiymat qaytaradigan rekursiv funksiya
//fun main() {
//    println(oila(5))
//
//}
//fun oila(farzand:Int):String{
//    if (farzand<=0){
//        return "Farzandim yo'q"
//    }else{
//        println(oila(farzand-1))
//        return "Meni $farzand ta bor"
//    }
//}

//fun main() {
//    var names = arrayOf("Muhammadamin","Ilmiddin","Iskandar",
//        "Muhammadodil","Muhammadyusuf","Diyorbek")
//    for (i in 0 until 6){
//        println(i)
//        println(names[i])
//    }
//}

//
//fun main() {
//    val names = arrayOf("Muhammadamin","Ilmiddin","Iskandar",
//      "Muhammadodil","Muhammadyusuf","Diyorbek")
//    for (i in names.indices){
//        println(names[i])
//    }
//
//}

//
//
//fun main() {
//    val names = arrayOf("Muhammadamin","Ilmiddin","Iskandar",
//        "Muhammadodil","Muhammadyusuf","Diyorbek")
//    for (i in names){
//        println(i)
//    }
//
//}

//
//fun main() {
//    val buyumlar = arrayOfNulls<String>(4)
//    buyumlar[0] = "Notebook"
//    buyumlar[1] = "Klaviatura"
//    buyumlar[2] = "sichqoncha"
//    buyumlar[3] = "Zaryadchik"
//    for (s in buyumlar){
//        println(s)
//
//    }
//}

fun main() {
      
}