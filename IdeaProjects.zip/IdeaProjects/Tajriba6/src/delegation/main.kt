package delegation

//fun main(args: Array<String>) {
//     var arraylist = ArrayList<String>()
//     arraylist.add("Kotlin")
//
//    arraylist.add("Android")
//     println("Array list ---->")
//    for(i in arraylist)
//        println(i)
//
//    arraylist.add( 1 , "Java")
//    println("Arraylist after insertion ---->")
//    for(i in arraylist)
//        println(i)
//}





//fun main(args: Array<String>) {
//    // creating empty arraylist using constructor
//    var arraylist=ArrayList<String>()
//    //adding String elements in the list
//    arraylist.add("Kotlin")
//    arraylist.add("Java")
//    arraylist.add("Android")
//    // creating new arraylist1
//    var arraylist1=ArrayList<String>()
//    //adding all elements from arraylist to arraylist1
//    println("Elements in arraylist1 -->")
//    arraylist1.addAll(arraylist)
//    for(i in arraylist1)
//        println(i)
//}



//fun main(args: Array<String>) {
//     var arraylist=ArrayList<Int>()
//     arraylist.add(10)
//    arraylist.add(20)
//    arraylist.add(30)
//    arraylist.add(40)
//    arraylist.add(50)
//
//    for(i in arraylist)
//        print("$i ")
//    println()
//    println("Accessing the index 2 of arraylist: "+arraylist.get(3))
//}



//fun main(args: Array<String>) {
 //    var arraylist = ArrayList<String>()

//    arraylist.add("Kotlin")
//    arraylist.add("Android")
//    arraylist.add("Java")
//    arraylist.add("Python")
 //    for (i in arraylist)
//        print("$i ")
//    println()
 //    arraylist.set(3, "Flutter")
 //    for (i in arraylist)
//        print("$i ")
//}


//fun main(args: Array<String>) {
//     var arraylist=ArrayList<String>()
//     arraylist.add("Kotlin")
//    arraylist.add("Android")
//    arraylist.add("Java")
//
//     for(i in arraylist)
//        print("$i ")
//    println()
//    println("The index of the element is: "+arraylist.indexOf("Android"))
//}


//fun main(args: Array<String>) {
//     var arraylist=ArrayList<String>()
//
//    arraylist.add("Kotlin")
//    arraylist.add("Android")
//    arraylist.add("Java")
//
//    arraylist.remove("Java")
//     for(i in arraylist)
//        print("$i ")
//}




//fun main(args: Array<String>) {
//
//    var arraylist=ArrayList<Int>()
//
//    arraylist.add(10)
//    arraylist.add(20)
//    arraylist.add(30)
//    arraylist.add(40)
//    arraylist.add(50)
//
//
//    for(i in arraylist)
//        print("$i ")
//    arraylist.clear()
//    println()
//    println("The size of arraylist after clearing all elements: "+arraylist.size)
//}



//fun main(args: Array<String>) {
//    val a = listOf('1', '2', '3')
//    println(a.size)
//    println(a.indexOf('2'))
//    println(a[2])
//}



//fun main(args: Array<String>) {
//    //creating list of strings
//    val a = listOf("Kotlin", "Android", "Java", "Python")
//    println("The size of the list is: "+a.size)
//    println("The index of the element Android is: "+a.indexOf("Android"))
//    println("The element at index "+a[2])
//    for(i in a.indices){
//        println(a[i])
//    }
//}



//fun main(args: Array<String>)
//{
//    val numbers = listOf(1, 5, 7, 32, 0, 21, 1, 6, 10)
//
//    val num1 = numbers.get(0)
//    println(num1)
//
//    val num2 = numbers[7]
//    println(num2)
//
//    val index1 = numbers.indexOf(1)
//    println("The first index of number is $index1")
//
//    val index2 = numbers.lastIndexOf(1)
//    println("The last index of number is $index2")
//
//    val index3 = numbers.lastIndex
//    println("The last index of the list is $index3")
//}



//fun main(args: Array<String>)
//{
//    val numbers = listOf(1, 5, 7, 32, 0, 21, 1, 6, 10)
//    println(numbers.first())
//    println(numbers.last())
//}



//fun main(args: Array<String>)
//{
//    val names = listOf("Asadbek", "Daler", "Alijon", "Valijon",
//        "Elyor", "Iftixor", "Quvonch")
//
 //    for (name in names) {
//        print("$name, ")
//    }
//    println()
//
 //    for (i in 0 until names.size) {
//        print("${names[i]} ")
//    }
//    println()
//
 //    names.forEachIndexed({i, j -> println("names[$i] = $j")})
//
//    val it: ListIterator<String> = names.listIterator()
//    while (it.hasNext()) {
//        val i = it.next()
//        print("$i ")
//    }
//    println()
//}



//
//fun main(args: Array<String>)
//{
//    val list = listOf(8, 4, 7, 1, 2, 3, 0, 5, 6 )
//
//    val asc = list.sorted()
//    println(asc)
//
//    val desc = list.sortedDescending()
//    println(desc)
//}
//



//fun main(args: Array<String>)
//{
//    val list = listOf(8, 4, 7, 1, 2, 3, 0, 5, 6 )
//
//    val res = list.contains(0)
//
//    if (res)
//        println("The list contains 0")
//    else
//        println("The list does not contain 0")
//
//    val result = list.containsAll(listOf(3, -1))
//
//    if (result)
//        println("The list contains 3 and -1")
//    else
//        println("The list does not contain 3 and -1")
//}



//fun main(args: Array<String>)
//{
//     val seta = setOf("Kotlin" , "Android", "Java")
//     val setb = setOf( "K" , "A" , "J" )
//     val setc = setOf( 1 ,2 , 3 , 4 )
//
//    for(item in seta)
//        print( item )
//    println()
//    for(item in setb)
//        print( item )
//    println()
//    for(item in setc)
//        print( "$item ")
//}



//fun main(args: Array<String>) {
//
//    val captains = setOf("Sarvar", "Jasur", "Alisher", "Bekzod", "Akbar", "Dilshod")
//
//    println("The element at index 2 is: " + captains.elementAt(2))
//
//    println("The index of element is: " + captains.indexOf("Jasur"))
//
//    println("The last index of element is: " + captains.lastIndexOf("Akbar"))
//}



//fun main(args: Array<String>){
//    val captains = setOf(1,2,3,4,"Ronaldo","Messi",
//        "Aguero","Rooney","Nani","Neymar")
//
//    println("The first element of the set is: "+captains.first())
//
//    println("The last element of the set is: "+captains.last())
//}
//



//fun main(args: Array<String>) {
//
//    val num = setOf(1 ,2, 3, 4, 5, 6, 7, 8)
//
//    println("The number of element in the set is: "+num.count())
//    println("The maximum element in the set is: "+num.max())
//    println("The minimum element in the set is: "+num.min())
//    println("The sum of the elements in the set is: "+num.sum())
//    println("The average of elements in the set is: "+num.average())
//}




//fun main(args: Array<String>){
//    val captains = setOf(1,2,3,4,"Ronaldo","Messi",
//        "Nani","Vidic","Marcelo","Neymar")
//
//
//    var name = "Neymar"
//    println("The set contains the element $name or not?" +
//            " "+captains.contains(name))
//
//    var num = 5
//    println("The set contains the element $num or not?" +
//            " "+captains.contains(num))
//
//    println("The set contains the given elements or not?" +
//            " "+captains.containsAll(setOf(1,3,"Nani")))
//}



//fun main(args: Array<String>) {
//     val seta = setOf<String>()
//     val setb =setOf<Int>()
//
//
//    println("seta.isEmpty() is ${seta.isEmpty()}")
//
//     println("seta == setb is ${seta == setb}")
//
//    println(seta)
//}




//fun main(args: Array<String>)
//{
//    val mutableSetA = mutableSetOf<Int>( 1 , 2 , 3 , 4 , 3);
//    println(mutableSetA)
//
//    val mutableSetB = mutableSetOf<String>("Kotlin","Android" , "Java");
//    println(mutableSetB)
//
//    val mutableSetC = mutableSetOf<Int>()
//    println(mutableSetC)
//}



//fun main(args: Array<String>)
//{
//    val mutableSetA = mutableSetOf<Int>( 1 , 2 , 3 , 4 , 3);
//    println(mutableSetA)
//
//    val mutableSetB = mutableSetOf<String>("Kotlin","Android" , "Java");
//    println(mutableSetB)
//
//    val mutableSetC = mutableSetOf<Int>()
//    println(mutableSetC)
//}


//fun main(args: Array<String>){
//    val captains = mutableSetOf(1,2,3,4,"Ronaldo","Messi",
//        "Neymar","Modric","Muller","Mbappe")
//
//    println("The first element of the set is: "+captains.first())
//
//    println("The last element of the set is: "+captains.last())
//}



//fun main(args: Array<String>) {
//
//    val captains = mutableSetOf("Ronaldo","Messi","Neymar","Modric","Muller","Mbappe")
//
//    println("The element at index 2 is: "+captains.elementAt(2))
//
//    println("The index of element is: "+captains.indexOf("Modric"))
//
//    println("The last index of element is: "+captains.lastIndexOf("Muller"))
//}


//fun main(args: Array<String>)
//{
//    val seta = mutableSetOf( 1 , 2 , 3 , 4 , 3);
//
//    for(item in seta)
//        println( item )
//}


//fun main(args: Array<String>){
//    val captains = mutableSetOf(1,2,3,4,"Ronaldo","Messi",
//        "Root","Malinga","Rohit","Dhawan")
//
//
//    var name = "Dhawan"
//    println("The set contains the element $name or not?" +
//            " "+captains.contains(name))
//
//    var num = 5
//    println("The set contains the element $num or not?" +
//            " "+captains.contains(num))
//
//    println("The set contains the given elements or not?" +
//            " "+captains.containsAll(setOf(1,3,"Root")))
//}


//fun main(args: Array<String>) {
//     val seta = mutableSetOf<String>()
//     val setb = mutableSetOf<Int>()
//
//    println("seta.isEmpty() is ${seta.isEmpty()}")
//
//    println("seta == setb is ${seta == setb}")
//
//    println(seta)
//}



//fun main(args: Array<String>)
//{
//    val seta = hashSetOf(1,2,3,3);
//     println(seta)
//
//    val setb = hashSetOf("Kotlin","Android","Java");
//    println(setb);
//
//}


//fun main(args: Array<String>)
//{
//    val seta = hashSetOf<Int>();
//    println(seta)
//
//    //ading elements
//    seta.add(1)
//    seta.add(2)
//
//    val newset = setOf(4,5,6)
//    seta.addAll(newset)
//
//    println(seta)
//
//    seta.remove(2)
//    println(seta)
//}



//fun main(args: Array<String>)
//{
//    //declaring a hash set of integers
//    val seta = hashSetOf(1,2,3,5);
//
//    //traversing in a set using a for loop
//    for(item in seta)
//        println(item)
//}

//fun main(args: Array<String>)
//{
//    //declaring a map of integer to string
//    val map = mapOf(1 to "Kotlin", 2 to "Android" , 3 to "Java")
//    //printing the map
//    println( map)
//}



//fun main(args: Array<String>)
//{
//    //declaring a map of integer to string
//    val map = mapOf(1 to "One", 2 to "Two" , 3 to "Three", 4 to "Four")
//
//    println("Map Entries : "+map)
//
//    println("Map Keys: "+map.keys )
//
//    println("Map Values: "+map.values )
//}



//fun main() {
//
//    val ranks = mapOf(1 to "India",2 to "Australia",3 to "England",4 to "Africa")
//
//    println("The size of the map is: "+ranks.size)
//
//    println("The size of the map is: "+ranks.count())
//}

//
//fun main(args: Array<String>)
//{
//    val map1 = mapOf<String , Int>()
//
//    println("Entries: " + map1.entries) //entries of map
//
//    println("Keys:" + map1.keys) //keys of map
//
//    println("Values:" + map1.values) //values of map
//
//}



//fun main() {
//
//    val ranks = mapOf(1 to "India",2 to "Australia",3 to "England",4 to "Africa")
//
//    //method 1
//    println("Team having rank #1 is: "+ranks[1])
//    //method 2
//    println("Team having rank #3 is: "+ranks.getValue(3))
//    //method 3
//    println("Team having rank #4 is: "+ranks.getOrDefault(4, 0))
//    // method 4
//    val team = ranks.getOrElse(2 ,{ 0 })
//    println(team)
//}
//


//fun main() {
//    val colorsTopToBottom = mapOf("red" to 1, "orange" to 2, "yellow" to 3,
//        "green" to 4 , "blue" to 5, "indigo" to 6, "violet" to 7)
//    var color = "yellow"
//    if (colorsTopToBottom.containsKey(color)) {
//        println("Yes, it contains color $color")
//    } else {
//        println("No, it does not contain color $color")
//    }
//    val value = 8
//    if (colorsTopToBottom.containsValue(value)) {
//        println("Yes, it contains value $value")
//    } else {
//        println("No, it does not contain value $value")
//    }
//}
//
//




//fun main(args: Array<String>)
//{
//    //lets make two values with same key
//    val map = mapOf(1 to "Java",2 to "Android" , 1 to "Kotlin")
//    // return the map entries
//    println("Entries of map : " + map.entries)
//}
//



//fun main(args: Array<String>){
//
//    val hashMap:HashMap<Int,String> = HashMap<Int,String>() //define empty hashmap
//    hashMap.put(1,"Ronaldo")
//    hashMap.put(3,"Messi")
//    hashMap.put(4,"Neymat")
//    hashMap.put(2,"Mbappe")
//    println(".....traversing hashmap.......")
//    for(key in hashMap.keys){
//        println("Element at key $key = ${hashMap[key]}")
//    }}

//




//fun main(args: Array<String>){
//    val hashMap:HashMap<String,String> = HashMap<String,String>(3)
//    hashMap.put("name","Sanjar")
//    hashMap.put("city","Tashkent")
//    hashMap.put("department","Software Development")
//    println(".....traversing hashmap.......")
//    for(key in hashMap.keys){
//        println("Element at key $key = ${hashMap[key]}")
//    }
//    println(".....hashMap.size.......")
//    println(hashMap.size)
//    hashMap.put("hobby","Travelling")
//    println(".....hashMap.size after adding hobby.......")
//    println(hashMap.size)
//    println(".....traversing hashmap.......")
//    for(key in hashMap.keys){
//        println("Element at key $key = ${hashMap.get(key)}")
//    }
//}







//fun main(args: Array<String>){
//    val hashMap:HashMap<Int,String> = HashMap<Int,String>()
//    hashMap.put(1,"Ronaldo")
//    hashMap.put(3,"Messi")
//    hashMap.put(4,"Neymar")
//    hashMap.put(2,"Mbappe")
//    println(".....traversing hashmap.......")
//    for(key in hashMap.keys){
//        println("Element at key $key = ${hashMap[key]}")
//    }
//    hashMap.replace(3,"Modric")
//    hashMap.put(2,"Rooney")
//    for(key in hashMap.keys){
//        println("Element at key $key = ${hashMap[key]}")
//    }
//}
