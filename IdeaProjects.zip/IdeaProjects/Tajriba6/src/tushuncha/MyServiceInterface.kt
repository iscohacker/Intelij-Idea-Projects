package tushuncha

interface MyServiceInterface {
    fun parametrliQaytaradigan()
    fun parametrliQaytarmaydigan()
    fun parametrsizQaytaradigan()
    fun parametrsizQaytarmaydigan()

}