package DataandTime

import java.text.SimpleDateFormat
import java.util.*
//
//fun main() {
//    val date = Date()
//    val simpleDateFormat = SimpleDateFormat("dd.MM.yyyy , HH:mm:ss ")
//    val str = simpleDateFormat.format(date)
//    println(str)
//
//}
fun main() {
    val str = "12.08.209"

    val simpleDateFormat = SimpleDateFormat("dd.MM.yyyy")
    val date = simpleDateFormat.parse(str)
    println(date)
}