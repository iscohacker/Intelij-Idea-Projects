package Masala1_100

fun main() {
    println("1dan 100gacha barcha  juft sonlar⬇️")
    birdanYuzgacaJuft()

    println("1 dan 100gacha 3ga bo'linadigan sonlar⬇️")
    birdanYuzgacha3ga()

    println("1dan 100gacha 5 ga bo'linadigan sonlar⬇️")
    birdanYuzgacha5g()

}

fun birdanYuzgacaJuft() {
    for (i in 1 until 100) {
        if (i % 2 == 0) {
            println("$i,")
        }
    }
}
fun birdanYuzgacha3ga(){
    for (i in 1 until 100) {
        if (i % 3 == 0) {
            println("$i,")
        }
    }
}
fun birdanYuzgacha5g(){
    for (i in 1 until 100) {
        if (i % 5 == 0) {
            println("$i,")
        }
    }
}

