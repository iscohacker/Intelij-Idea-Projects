package XozirgacaOtgan

import java.time.LocalDateTime
import java.time.temporal.ChronoUnit

fun main() {
    val yil = 2000
    val oy = 4
    val kun = 27
    val soat = 17
    val minut = 8

    val now = LocalDateTime.now()

    val local = LocalDateTime.of(yil, oy, kun, soat, minut)

    val yillik = ChronoUnit.YEARS.between(local, now)
    val oylik = ChronoUnit.MONTHS.between(local, now) % 12
    val kunlik = ChronoUnit.DAYS.between(local, now) % 30
    val soatlik = ChronoUnit.HOURS.between(local, now) % 24
    val minutlik = ChronoUnit.MINUTES.between(local, now) % 60

    println("Siz kiritgan vaqt: $yil-yil, $oy-oy, $kun-kun, $soat-soat, $minut-daqiqa")
    println("Hozirgi vaqt: ${now.year}-yil, ${now.monthValue}-oy, ${now.dayOfMonth}-kun, ${now.hour}-soat, ${now.minute}-daqiqa")
    println("O'tgan vaqt: $yillik yil, $oylik oy, $kunlik kun, $soatlik soat, $minutlik daqiqa")

}
