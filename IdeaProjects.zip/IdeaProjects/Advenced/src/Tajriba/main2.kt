package Tajriba

import java.io.File

//fun main() {
//    val file = File("D:\\IDEA\\TajribaUchun file\\iskandar.txt")
//    file.createNewFile()
//    file.writeText("Assalomu alaykum!")
//
//}

fun main() {
    val papka = File("D:\\Papka1\\Papka2\\Papka3")
    papka.mkdirs()
    //mkdir - bitta fayl yaratish
    //mkdirs - bir nechta fayl yaratish

    val file = File("D:\\Papka1\\Papka2\\Papka3\\iskandar.txt")
    file.createNewFile()
    file.writeText("Assalomu alaykum Developers")
}//papkalar yaratish


