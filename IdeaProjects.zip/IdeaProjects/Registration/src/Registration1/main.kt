package Registration1

import java.util.*
import kotlin.collections.ArrayList

fun main() {
    val input = Scanner(System.`in`)
    var list = ArrayList<String>()
    while (true){
        println("1->Qo'shish\n" +
                "2->Ko'rish")
        var kirit = input.nextInt()
        when(kirit){
            1->{
                print("Ismingizni kiriting: ")
                val name = input.next()
                print("Familyangizni kiriting: ")
                val name1 = input.next()
                list.add(name)
                list.add(name1)
                println("Ma'lumotlar saqlandi")
            }
            2->{
                if (list.isNotEmpty()){
                    for (i in 0 until list.size){
                        println(list[i])
                    }
                }else{
                    println("Ro'yxat bo'sh! Ma'lumotlar kiritilganini tekshiring")
                }
            }
        }
    }
}