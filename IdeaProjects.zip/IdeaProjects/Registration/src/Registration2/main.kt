package Registration2

import java.util.*

fun main() {
    val usernameList = arrayOfNulls<String>(100)
    val passwordList = arrayOfNulls<String>(100)
    var input = Scanner(System.`in`)
    var sanoq = 0

    while(true){
        println("1->Ro'yxatdan otish\n" +
                "2->Ko'rish\n" +
                "3->O'chirish\n" +
                "4->Tahrirlash\n" +
                "5->Qidirish")
        var n = input.nextInt()
        when(n){
            1->{
                print("Foydalanuvchi nomi kiriting: ")
                var username = input.next()
                print("Parol kiriting: ")
                var password = input.next()
                usernameList[sanoq] = username
                passwordList[sanoq] = password
                sanoq++
                println("Ma'lumotlar saqlandi!")


            }
            2->{
                for (i in 0 until sanoq){
                    println("Username: ${usernameList[i]} " +
                            "Password: ${passwordList[i]}")
                }

            }
            3->{
                println("Qaysi indeksdagi ma'lumotni o'chirmoqchisiz: ")
                for (i in 0 until sanoq){
                    println(" $i -> ${usernameList[i]},${passwordList[i]}")

                }
                var index = input.nextInt()
                for (i in index until sanoq){
                    usernameList[i] = usernameList[i+1]
                    passwordList[i] = passwordList[i+1]
                }
                sanoq--
                println("Ma'lumotlar o'chirib yuborildi!")

            }
            4->{
                println("Qaysi elementi tahrirlamoqchisiz: ")
                for (i in 0 until sanoq){
                    println("$i -> ${usernameList[i]},${passwordList[i]}")
                }
                var index = input.nextInt()
                println("Yangi foydalanuvchi nomini kiriting: ")
                usernameList[index] = input.next()
                println("Yangi parolni kiriting: ")
                passwordList[index] = input.next()
                println("Ma'lumotlar tahrirlandi!")

            }
            5->{
                println("Qidirmoqchi bo'lgan elementingizni kiriting: ")
                var searchWord = input.next()
                for (i in 0 until sanoq){
                    if (usernameList[i]!!.lowercase().contains(searchWord) || passwordList[i]!!.lowercase().contains(searchWord)){
                        println("${usernameList[i]},${passwordList[i]}")
                    }
                }

            }
        }
    }
}