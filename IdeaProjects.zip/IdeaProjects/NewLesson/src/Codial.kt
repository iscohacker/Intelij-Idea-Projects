class Codial {
    var name: String? = null
    var age: Int? = null
    constructor(name: String?, age: Int?) {
        this.name = name
        this.age = age
    }
    override fun toString(): String {
        return "Codial(name=$name, age=$age)"
    }
    class Android20 {
        var city: String? = null
        var phone: String? = null
        constructor(city: String?, phone: String?) {
            this.city = city
            this.phone = phone
        }
        override fun toString(): String {
            return "Android20(city=$city, phone=$phone)"
        }
    }
}