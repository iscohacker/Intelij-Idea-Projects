fun main() {
    var codial = Codial("Iskandar",17)
    println(codial)
}