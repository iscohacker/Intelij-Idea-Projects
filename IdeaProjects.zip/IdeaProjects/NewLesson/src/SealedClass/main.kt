package SealedClass
sealed class Color {
    class Red : Color()
    class Yellow : Color()
    class Green : Color()
}
fun selectColor(c:Color){
    when(c){
        is Color.Red -> println("Men yoqtirgan rang qizil")
        is Color.Yellow -> println("Men yoqtirgan rang sariq")
        is Color.Green -> println("Men yoqtirgan rang yashil")
    }
}
fun main() {
    val green = Color.Green()
    selectColor(green)
}