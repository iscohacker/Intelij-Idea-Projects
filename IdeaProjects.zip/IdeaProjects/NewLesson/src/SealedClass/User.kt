package SealedClass

class User {
}