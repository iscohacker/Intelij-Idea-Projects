import java.lang.ArithmeticException
import java.util.*

//fun main() {
//    try {
//        println(10/0)
//
//    }catch (e:Exception){
//        println("Xatolik yuz berdi, qaytadan urining!")
//    }
//}
//fun main() {
//    try {
//        println("Raqam kiriting, iltimos : ")
//        val number = Scanner(System.`in`).nextInt()
//        println("Siz kiritgan raqam: $number")
//    }catch (e:Exception){
//        println("Xatolik yuz berdi , qaytadan urining!")
//    }finally {
//        println("Dasturdan foydalanganligingiz uchun raxmat...👌😒")
//    }
//}





//fun main() {
//    try {
//        println("Yoshingizni kiriting , iltimos")
//        val callback = Scanner(System.`in`).nextInt()
//        sayage(callback)
//    }catch (a:Exception){
//        println(a.message)
//    }
//}
//fun sayage(age:Int){
//    if (age>=16){
//        println("Siz pasport olsangiz mumkin.")
//    }else{
//        throw ArithmeticException("Yoshingiz yetmayapti.")
//    }
//}


fun main() {
    val a: Int? = null //? null bop qoliwi nm degani
    val b:Int = if (a==null) 10 else a
    println(b)
}
