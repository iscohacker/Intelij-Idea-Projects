package YesParYesQiy

fun main() {
    println(isco("Iskandarbek "))
    println(asal("Asal"))
    println(atirgul("Atir"))
    println(tugilgan_yil(2006))
    println(kotlin("Kotlin yaratilganiga yil:"))
    println(ustoz("Ilhomjon"))
    println(codial("Codial eng zor IT academy mi:"))
    println(chegirma(50))
    println(soroq("So'roq gapn oxiriga qo'yiladigan belgi:"))
    println(muhammadodil("MuhammadOdil zor dasturchimi:"))
}

fun isco(name:String):Int{
    print(name)
    return  17
}
fun asal(asal:String):String{
    print(asal)
    return " ari"
}
fun atirgul(gul:String):String{
    print(gul)
    return "gul"
}
fun kotlin(yil:String):Int{
    print(yil)
    return 2011
}fun tugilgan_yil(yil:Int):String{
    print(yil)
    return "-yil mening tavvallud yilim"
}

fun ustoz(ismi:String):String{
    print(ismi)
    return " Ibragimov"
}
fun codial(savol:String):Boolean{
    print(savol)
    return true
}

fun chegirma(foiz:Int):String{
    print(foiz)
    return "-foizli chegirma guruhdagi eng yuqori bal to'plagan o'quvchiga beriladi "
}
fun soroq(soroq:String):Char{
    print(soroq)
    return '?'
}
fun muhammadodil(muhammadodil:String):Boolean{
    print(muhammadodil)
    return false
}