package NoParYesQiy

fun main() {
    println(ism())
    println(familya())
    println(yosh())
    println(shaxar_tuman())
    println(qishloq())
    println(mahalla())
    println(uyraqam())
    println(maktab())
    println(sinf())
}
fun ism():String {
    return "Iskandarbek"
}
fun familya():String{
    return "Nosirov"
}
fun yosh():Int{
    return 17
}
fun shaxar_tuman():String{
    return "Farg'ona tumani"
}
fun qishloq():String{
    return "Arab"
}
fun mahalla():String{
    return "Qovunchi"
}
fun uyraqam():Int{
    return 8
}
fun maktab():Int{
    return 8
}
fun sinf():Int{
    return 11
}
