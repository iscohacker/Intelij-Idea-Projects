package YesParNoQiy

fun main() {
    isimsora("Iskandarbek")
    yoshnisora(17)
    familyasora("Nosirov")
    maktabsora(8)
    sinfsora(11)
    tumansora("Farg'ona tumani")
    mfysora("Yuqori Gulshan")
    qishloqsora("Arab")
    mahallasora("Qovunchi")
    uyraqamsora(8)
    kasbsora("Android Dasturchi")
}
fun isimsora(name:String){
    println("Ismingiz: $name")
}
fun yoshnisora(age:Int){
    println("Yoshingiz: $age")
}
fun familyasora(familya:String){
    println("Familyangiz: $familya")
}
fun maktabsora(maktab:Int){
    println("Maktabingiz: $maktab")
}
fun sinfsora(sinf:Int){
    println("Sinfingiz: $sinf")
}
fun tumansora(tuman:String){
    println("Istiqomat qilayotgan tumaningiz: $tuman")
}
fun mfysora(mfy:String){
    println("MFY ingiz: $mfy")
}
fun qishloqsora(qishloq:String){
    println("Qishloqingiz: $qishloq")
}
fun mahallasora(mahalla:String){
    println("Mahallangiz: $mahalla")
}
fun uyraqamsora(uyraqam:Int){
    println("Uy raqamingiz: $uyraqam")
}
fun kasbsora(kasb:String){
    println("Kasbingiz: $kasb")
}
