package NoParNoQiy

fun main() {
    salom()
    alik()
    axvol()
    yordam()
    pul()
    kompyuter()
    sichqoncha()
    televizor()
    mac()
}
fun salom(){
    println("Assalomu alaykum")
}
fun alik(){
    println("Va alaykum assalom")
}
fun axvol(){
    println("Axvollaringiz yaxshimi")
}
fun yordam(){
    println("Yordam kerakmi , ey birodar")
}
fun pul(){
    println("Hohlasangiz pul berib turaman")
}
fun kompyuter(){
    println("Mening Acer brendiga tegishli noutbukim bor")
}
fun sichqoncha(){
    println("Mening simsiz sichqoncham bor")
}
fun televizor(){
    println("Bizni dars xonamizdsgi televizor YASIN brendiga tegishli")
}
fun mac(){
    println("Ustozimizni MAC i bor")
}