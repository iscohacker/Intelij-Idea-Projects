package Vazifa_2
fun main() {
    val str = "Developer"
    for (i in 0 until str.length) {
        print(str[i])
        print(str[i])
    }
}
//creator: Iskandar Nosirov