package Vazifa_1

fun main() {
    val n = 50
    var s = 0.0

    for (i in 1..n) {
        s += 1.0 / i
    }
    println("S = $s")
}
//creator : Iskandar Nosirov

