package Vazifa_3
fun main() {
    val n = 5
    val a = 6f

    for (i in 1..n) {
        println(Math.pow(a.toDouble(), i.toDouble()))
    }
}
//creator : Iskandar Nosirov