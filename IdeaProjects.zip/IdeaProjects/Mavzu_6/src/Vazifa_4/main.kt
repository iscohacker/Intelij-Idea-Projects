package Vazifa_4
    fun main() {
        val a = 3
        val b = 9

        for (i in a..b) {
            for (n in a..i) {
                print(i)
            }
        }
    }
//creator: Iskandar Nosirov

