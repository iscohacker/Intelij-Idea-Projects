package Vazifa_2

class Abonent {
    var id : Int? = null
    var familya : String? = null
    var ismi : String? = null
    var ShaxarIchiSuxbatVaqti : Int = 0
    var ShaxardanTashqariSuxbatVaqti : Int = 0

    constructor()

    constructor(
        id: Int?,
        familya: String?,
        ismi: String?,
        ShaxarIchiSuxbatVaqti: Int,
        ShaxardanTashqariSuxbatVaqti: Int
    ) {
        this.id = id
        this.familya = familya
        this.ismi = ismi
        this.ShaxarIchiSuxbatVaqti = ShaxarIchiSuxbatVaqti
        this.ShaxardanTashqariSuxbatVaqti = ShaxardanTashqariSuxbatVaqti
    }

    override fun toString(): String {
        return "Abonent(id=$id, familya=$familya, ismi=$ismi, ShaxarIchiSuxbatVaqti=$ShaxarIchiSuxbatVaqti, ShaxardanTashqariSuxbatVaqti=$ShaxardanTashqariSuxbatVaqti)"
    }



}
