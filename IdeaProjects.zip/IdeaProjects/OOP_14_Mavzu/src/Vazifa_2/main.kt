package Vazifa_2

fun main() {
    val abubakir = Abonent(1, "Abubakirov", "Abubakir", 5, 2)
    val ali = Abonent(2, "Aliyev", "Ali", 6, 11)
    val umar = Abonent(3, "Umarov", "Umar", 7, 0)
    val usmon = Abonent(4, "Usmonov", "Usmon", 8, 9)


    println("Shaxar ichida ko'p vaysaganlar.")

    val abonenntlar = arrayOf(abubakir, umar, ali, usmon)

    for (abonent in abonenntlar) {
        if (abonent.ShaxarIchiSuxbatVaqti > abonent.ShaxardanTashqariSuxbatVaqti) {
            println(abonent)
        }

    }
    println("")
    println("ShaxarlarAro ko'p vaysaganlar.")

    for (abonent in abonenntlar) {
        if (abonent.ShaxarIchiSuxbatVaqti < abonent.ShaxardanTashqariSuxbatVaqti) {
            println(abonent)
        }
    }
    println("")
    println("ShaxarlarAro vaysamaganlar.")

    for (abonent in abonenntlar) {
        if (abonent.ShaxardanTashqariSuxbatVaqti == 0) {
            println(abonent)
        }
    }
}
