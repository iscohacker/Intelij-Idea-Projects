package Vazifa_1

fun main() {

    val circlee = Circle()
    println(circlee)

    val restanglee = Rectangle()
    println(restanglee)

}