package Vazifa_1

abstract class Shape {
    var color : String = "sariq"
    get() = field

    fun Area():Double {
        return 1.0
    }

    override fun toString(): String {
        return "Shape(Color=$color)"
    }
}