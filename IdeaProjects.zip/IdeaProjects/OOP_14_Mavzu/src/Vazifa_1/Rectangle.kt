package Vazifa_1

class Rectangle : Shape(){
    var lenght : Double? = null
    var widht : Double? = null

}