package Vazifa_1

class Circle : Shape(){
    var radius : Double? = null

}