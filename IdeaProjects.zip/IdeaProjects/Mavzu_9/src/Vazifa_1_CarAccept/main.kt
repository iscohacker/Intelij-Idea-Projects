package Vazifa_1_CarAccept
import java.lang.Exception
import java.util.*

fun main() {
    val input = Scanner(System.`in`)

    var barchaJavob = 0
//1-savol
    println("Assalomu alaykum , haydovchilik guvohnomasi olish boyicha test platformasiga xush kelibsiz!")
    println("1)Shaxar hududida necha tezlik bilan harakatlanish kerak?")
    val javoblar1 = arrayOf("50 km/s", "60 km/s", "70 km/s", "40 km/s")
    val togriJavob1 = "60 km/s"
    var belgilanganJavob1 = ""
    for (i in javoblar1.indices){
        println("${i+1}.${javoblar1[i]}")
    }
    print("Variantlardan birini tanlang: ")
    val variant1 = input.nextInt()
    try {
        belgilanganJavob1 = javoblar1[variant1-1]
        if (togriJavob1.compareTo(belgilanganJavob1) == 0){
            barchaJavob+=1
            println("To'g'ri javobni belgiladingiz")
        }else{
            println("Noto'g'ri javobni belgiladingiz")
        }
    }catch (e: Exception){
        println("Siz belgilagan javob variantlar qatorida yo'q")
    }



    //2-savol
    println("2)Svetaforning qaysi rangida yurishga ruxsat beriladi?")
    val javoblar2 = arrayOf("Qizil" , "Sariq" , "Yashil","Oq")
    val togriJavob2 = "Yashil"
    var belgilanganJavob2 = ""
    for (i in javoblar1.indices){
        println("${i+1}.${javoblar2[i]}")
    }
    print("Variantlardan birini tanlang: ")
    val variant2 = input.nextInt()
    try {
        belgilanganJavob2 = javoblar2[variant2-1]
        if (togriJavob2.compareTo(belgilanganJavob2) == 0){
            barchaJavob+=1
            println("To'g'ri javobni belgiladingiz👌")
        }else{
            println("Noto'g'ri javobni belgiladingiz😒")
        }
    }catch (e: Exception){
        println("Siz belgilagan javob variantlar qatorida yo'q😢")
    }




    //3-savol
    println("3)Qaysi davlatning magistral yollarida tezlik cheklanmagan?")
    val javoblar3 = arrayOf("Xitoy" , "Rossiya" , "AQSH","Germaniya")
    val togriJavob3 = "Germaniya"
    var belgilanganJavob3 = ""
    for (i in javoblar1.indices){
        println("${i+1}.${javoblar3[i]}")
    }
    print("Variantlardan birini tanlang: ")
    val variant3 = input.nextInt()
    try {
        belgilanganJavob3 = javoblar3[variant3-1]
        if (togriJavob3.compareTo(belgilanganJavob3) == 0){
            barchaJavob+=1
            println("To'g'ri javobni belgiladingiz😁")
        }else{
            println("Noto'g'ri javobni belgiladingiz😊")
        }
    }catch (e: Exception){
        println("Siz belgilagan javob variantlar qatorida yo'q")
    }
    if (barchaJavob == 3){
        println("Siz testlarni juda yaxshi bajardingiz shu bilan birga " +
                "haydovchilik guvohnomasini olishingiz mumkin😍❤😊")
    }else if (barchaJavob ==2){
        println("Siz testlarda xatoliklarga yol qoydingiz, iltimos qaytadan urining.😂")
    }else if(barchaJavob==1){
        println("Testni qoniqarsiz tarzda bajardingiz , iltimos qayatadan urining.😎")
    }else{
        println("Afsuski siz umuman tog'ri javob topa olmadingiz!🤯")
    }
}