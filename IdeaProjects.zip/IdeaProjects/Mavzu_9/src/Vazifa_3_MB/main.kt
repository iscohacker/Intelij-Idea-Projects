package Vazifa_3_MB

import java.util.*

fun main() {
    try {
        print("Yuklab olmoqchi bo'lgan fayl hajmini kiriting,iltimos: ")
        val callback = Scanner(System.`in`).nextDouble()
        ellik(callback)
    }catch (a:Exception){
        println(a.message)
    }
}
fun ellik(age:Double){
    if (age<=50.0){
        println("Fayl yuklab olinmoqda...😊(Buni yuklab olish sahifasidan ko'rishingiz mumkin.)")
    }else{
        throw ArithmeticException("Faylni yuklab olishga trafik kamlik qiladi." +
                "(Trafik sotib oling yoki kichikroq faylni yuklab olishga harakat qiling.)")
    }
}
