package Vazifa_2

import java.lang.IndexOutOfBoundsException
import java.util.*

fun main() {
    // Birinchi holat: 10ni 0 ga bolish
    try {
        println(10 / 0)

    } catch (e: Exception) {
        println("Xatolik yuz berdi, qaytadan urining!")
    }


    // Ikkinchi holat: Uylanish yoshi
    var input = Scanner(System.`in`)
    print("Yoshingizni kiriting: ")
    var age = input.nextInt()
    if (age>18){
        println("Umuman olganda uylansangiz bo'ladi")
    }else{
        throw ArithmeticException("Uzr , lekin uylanishga biroz yoshlik qilasizda.")
    }
}
