package Ozimizniki

fun main() {
    println(ism())
    println(familya())
    println(yosh())
    println(top())
    println(soroq())
}
fun ism():String {
    return "Iskandarbek"
}
fun familya():String{
    return "Nosirov"
}
fun yosh():Int{
    return 17
}
fun top():Boolean{
    return true
}
fun soroq():Char{
    return '?'
}
