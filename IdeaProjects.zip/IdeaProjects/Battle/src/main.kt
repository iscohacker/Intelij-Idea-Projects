import java.util.Scanner

fun main() {
    val input = Scanner(System.`in`)
    println("Iltimos, so'zni kiriting:")
    val txt = input.nextLine()
    val teskarisoz = txt.reversed()
    print("Teskari so'z: ")
    println(" $teskarisoz")

    val s = "Koltin"
    println("lt sozlari almashmasi")
    println(s)

    val boshii = txt.substring(0,txt.length-2)
    val a = txt.substring(txt.length-2,txt.length-1)
    val b = txt.substring(txt.length-1, txt.length)
    print("Oxiridagi ikkita belgi almashgan so'z: ")
    println("$boshii$b$a")
}
