package Vazifa_2

fun main() {
    println(Daraxt.meva)
}
class Daraxt{

    companion object{
        val meva = "Shirin meva"
    }
}
/*
Companion object - bu class ichidagi object bolib u classdan obyekt olmasdan ishlatsam bo'ladigan funksiya
 */