package Vazifa_3


fun main() {
    println(Isco.acer)
    Isco.codial()
}

class Isco {
    companion object {
        val acer = "Men acer kompyuter ishlataman"
        fun codial(){
            println("Men Codial da o'qiyman")
        }
    }
}
/*
Companion - bu class ichida ishlab u class nomi bilan chaqirib ishlashi mumkin
Object - esa u singlton bolib uni funksiyalari tog'ridan tog'ri chiqaveradi
 */
