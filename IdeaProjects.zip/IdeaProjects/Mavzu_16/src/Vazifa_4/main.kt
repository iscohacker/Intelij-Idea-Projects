package Vazifa_4

fun main() {

    val a = 15
    println(a.birAyir())

    val name = "Iskandarbek"
    println(name.name())

    val togrimiYokinotugrimi = true
    println(togrimiYokinotugrimi.tanla())

    val znak = '?'
    println(znak.belgi())

    val son = 120
    println(son.ikkigaKopaytr())

}
fun Int.birAyir():Int{
    return this -1
}
fun String.name():String{
    return this
}
fun Boolean.tanla():Boolean{
    return this
}
fun Char.belgi():Char{
    return this
}
fun Int.ikkigaKopaytr():Int{
    return this * 2
}

/*
Extensions funksiya - bu  berilgan tipdagi
o’zgaruvchi orqali chaqiriladigan funksiya hisoblanadi
 */