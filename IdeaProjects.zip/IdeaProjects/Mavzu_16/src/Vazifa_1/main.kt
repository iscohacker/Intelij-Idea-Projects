package Vazifa_1

fun main() {
    println(Matem.engKichigi(12,99))
}

object Matem{
    fun engKichigi(a: Int, b: Int): Int {
        if (a < b) {
            return a
        } else {
            return b
        }
    }
}
/*
SinglTon (object) - bu bir marta obyekt olib
uni hohlagan joyimizda ishlatishimiz hisoblanadi!
 */