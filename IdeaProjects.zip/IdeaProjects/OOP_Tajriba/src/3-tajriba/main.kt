package `3-tajriba`
//
//fun main() {
//    val iskandarbek = Pupil()
//    iskandarbek.name = "Iskandar"
//    iskandarbek.age = 17
//    iskandarbek.forma = "Oq ko'ylak , qora shim"
//    iskandarbek.sinf = 11
//    iskandarbek.grade = 5.5
//    println(iskandarbek)
//
//}



fun main() {
    val iskandarbek = Pupil("iskandar" , "oq koylak , qora shim" , 5.5 , 11 , 17) //bu obyekt olish Pupil
    println(iskandarbek)

}