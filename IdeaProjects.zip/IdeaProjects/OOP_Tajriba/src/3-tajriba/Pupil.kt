package `3-tajriba`
//
//class Pupil {
//    var name : String? = null
//    var forma : String? = null
//    var grade : Double? = null
//    var sinf : Int? = null
//    var age : Int? = null
//    override fun toString(): String {
//        return "Pupil(name=$name, forma=$forma, grade=$grade, sinf=$sinf, age=$age)"
//    }
//
//}

class Pupil {
    var name : String? = null
    var forma : String? = null
    var grade : Double? = null
    var sinf : Int? = null
    var age : Int? = null

//clas dan obyekt oliw bn reski iwga tuwadigan ifoda
    constructor(name:String , forma:String , baho:Double , sinf:Int,age:Int)
    override fun toString(): String {
        return "Pupil(name=$name, forma=$forma, grade=$grade, sinf=$sinf, age=$age)"
    }
}