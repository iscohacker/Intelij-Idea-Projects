package `2-tajriba`

class Meva {
    var nomi : String? = null
    var rangi : String? = null

    fun display(){
        println("$nomi , $rangi")
    }
}