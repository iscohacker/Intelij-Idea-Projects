package `2-tajriba`

fun main() {
    val olma = Meva()
    olma.nomi = "Olma"
    olma.rangi = "Qizil"
    olma.display()

    val olxori = Meva()
    olxori.nomi = "Olxori"
    olxori.rangi = "Binafsharang"
    olxori.display()

    val banan = Meva()
    banan.nomi = "Banan"
    banan.rangi = "Sariq"
    banan.display()

    val kivi = Meva()
    kivi.nomi = "Kivi"
    kivi.rangi = "Yashil"
    kivi.display()

    val limon = Meva()
    limon.nomi = "Limon"
    limon.rangi = "Sariq"
    limon.display()
}



//ctrl+alt+l = tekislash