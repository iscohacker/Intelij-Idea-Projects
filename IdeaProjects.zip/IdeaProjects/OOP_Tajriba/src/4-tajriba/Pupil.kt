package `4-tajriba`

class Pupil(name:String,forma:String,baho:Double,sinf:Int,yosh:Int){
    var name : String? = null
    get() = field
    set(value){
        field = value
    }
    var forma : String? = null
        get() = field
        set(value){
            field = value
        }
    var baho : Double? = null
        get() = field
        set(value){
            field = value
        }
    var sinf : Int? = null
        get() = field
        set(value){
            field = value
        }
    var yosh : Int? = null
        get() = field
        set(value){
            field = value
        }



    init {
        this.name = name
        this.forma = forma
        this.baho = baho
        this.sinf = sinf
        this.yosh = yosh

    }//alt+insert = toString

    override fun toString(): String {
        return "Pupil(name=$name, forma=$forma, baho=$baho, sinf=$sinf, yosh=$yosh)"
    }

}