package `4-tajriba`

fun main() {
    val iskandar = Pupil("iskandar","standart",5.5,11,17)
    println(iskandar)
}

