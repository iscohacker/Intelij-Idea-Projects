package `5-tajriba`

class Baho : Odam() {
    var baxo : Double? = null

}