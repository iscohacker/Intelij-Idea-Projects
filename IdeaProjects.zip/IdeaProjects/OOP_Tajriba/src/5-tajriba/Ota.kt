package `5-tajriba`

class Ota : Bobo() {
    var mashina = "BMW M5"


    fun ishlash(){
        println("Sizlar uchun ishlayabmanda , bolalarim...")
    }

}