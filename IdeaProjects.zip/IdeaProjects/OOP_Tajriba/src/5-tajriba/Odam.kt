package `5-tajriba`

open class Odam {
    var name : String? = null
    var age : Int? = null

}