package `5-tajriba`

fun main() {
    var bobomurod = Bobo()
    var otabek = Ota()
    println(otabek.nasixatQilish())

    var student = Baho()
    student.name = "Iskandar"
    println(student.name)
    student.age = 17
    println(student.age)
    student.baxo = 5.5
    println(student.baxo)
}