package `5-tajriba`

open class Bobo {
    var soqol = "Uzun va oppoq soqol"

    fun nasixatQilish(){
        println("Yaxshi oqigin bolam...")
    }

}