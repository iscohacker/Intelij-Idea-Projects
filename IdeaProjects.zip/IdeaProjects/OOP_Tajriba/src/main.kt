fun main(args:Array<String>) {
    val isco : Persent = Persent()
    isco.ism = "Iskandarbek"
    isco.boyi = 170
    isco.vazni = 55.0
    isco.nafasOlish()

}
