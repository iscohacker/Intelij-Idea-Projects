package `6--maktaab`

open class Osimlik {
    var bargi  = "Yashil"
    var name : String? = null

    constructor(barg: String, name: String?) {
        this.bargi = barg
        this.name = name
    }

    fun fotosintez(){
        println("Karbonat angidridni yutib Kislorod(O) ni chiqaradi")
    }

    override fun toString(): String {
        return "Osimlik(bargi='$bargi', name=$name)"
    }
}