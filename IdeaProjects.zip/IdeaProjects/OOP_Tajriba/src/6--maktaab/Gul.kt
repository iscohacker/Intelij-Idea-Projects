package `6--maktaab`

class Gul : Osimlik {
    var hidi = "Xushbo'y"
    var rangi = "Qizil"

    constructor(barg: String, name: String?, hidi: String, rangi: String) : super(barg, name) {
        this.hidi = hidi
        this.rangi = rangi
    }

     override fun toString(): String {
        return "Gul(hidi='$hidi', rangi='$rangi')"
    }


}