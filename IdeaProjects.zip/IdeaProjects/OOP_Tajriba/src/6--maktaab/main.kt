package `6--maktaab`

fun main() {
    val lola = Gul("Yashil","Tog' lolasi","Juda ajoyib","Qizil")
    println(lola)
    lola.fotosintez()
}