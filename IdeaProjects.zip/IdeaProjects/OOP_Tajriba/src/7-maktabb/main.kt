package `7-maktabb`

fun main() {
    qoshish(5,5)
    qoshish(5.5,5.5)
    qoshish(5f,5f)

}

fun qoshish(a:Int, b:Int):Int{
    return a+b
}

fun qoshish(a:Double,b:Double):Double{
    return a+b
}

fun qoshish(a:Float,b:Float):Float{
    return a+b
}