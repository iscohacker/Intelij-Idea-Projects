package Gilos

class Gilos : Daraxt{
    val color = "Red"
    override fun genetika() {
        println("Genetika hama joiyda kerak")
    }
}
