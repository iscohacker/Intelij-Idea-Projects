package Gilos

fun main() {
    val giloss = Gilos()
    val qgilos = QashqarGilos(giloss)

    qgilos.genetika()

    println(giloss.color)

    qgilos.display()
}