package Gilos

interface Daraxt {
    fun genetika()
}