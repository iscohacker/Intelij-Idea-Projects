package Gilos

class QashqarGilos(d : Daraxt):Daraxt by d{
    fun display(){
        println("Qashqir gilos")
    }
}