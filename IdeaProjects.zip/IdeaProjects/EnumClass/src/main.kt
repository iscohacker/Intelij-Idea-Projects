fun main() {

    val user1 = User1("Alisher",23,"123456")
    println(user1.hashCode())

    val ali = user1.copy("Ali")
    println(ali)
    println(user1)
}

data class User1(var name:String,var age:Int,var phoneNumber:String)


