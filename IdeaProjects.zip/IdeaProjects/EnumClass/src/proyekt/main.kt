package proyekt
//
//fun main() {
//    val pupil1 = Pupil()
//    pupil1.name = "Iskandar"
//
//    val pupil2 = Pupil()
//    println(pupil2.name)
//}
//class Pupil{
//    var name : String = "Samandar"
//}
//
//fun main() {
//    Pupil.name = "Alexandr"
//    println(Pupil.name)
//}
//object Pupil{
//    var name : String = "Samandar"
//}

//fun main() {
//    println(Matematika.kattasiniTop(45, 78))
//}
//
//object Matematika {
//    fun kattasiniTop(a: Int, b: Int): Int {
//        if (a > b) {
//            return a
//        } else {
//            return b
//        }
//    }
//}
//
//fun main() {
//    val codial = Codial()
//    val codial2 = Codial()
//    val codial3 = Codial()
//    val codial4 = Codial()
//
//    codial4.display()
//}
//class Codial{
//    constructor(){
//        count++
//    }
//
//    fun display(){
//        println("Klasdan $count ta obyekt olingan")
//    }
//    companion object{
//        val admin = "Muxlisa"
//        var count = 0
//    }
//}

fun main() {
    val a = "Salom"
    println(a.uzunlik())
    val raqam = 123
    println(raqam.ikkigaKopaytr())

}
fun String.uzunlik():Int{
    return this.length
}
fun Int.ikkigaKopaytr():Int{
    return this * 2
}
