package ekrangaChiqar

import javax.swing.text.StyledEditorKit

fun main() {
    ekrangachiqar(123)
    ekrangachiqar("Salom")
    ekrangachiqar(true)
}
fun <Iskandar>ekrangachiqar(a:Iskandar){
    println(a)
}




//fun ekrangachiqar(a:Int) {
//    println(a)
//}
//fun ekrangachiqar(a:String) {
//    println(a)
//}
//fun ekrangachiqar(a:Boolean) {
//    println(a)
//}
