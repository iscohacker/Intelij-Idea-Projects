class User {
    var name:String? = null
    var age:Int? = null
    var phoneNumber:Int? = null

    constructor(name: String?, age: Int?, phoneNumber: Int?) {
        this.name = name
        this.age = age
        this.phoneNumber = phoneNumber
    }


    override fun toString(): String {
        return "User(name=$name, age=$age, phoneNumber=$phoneNumber)"
    }
}