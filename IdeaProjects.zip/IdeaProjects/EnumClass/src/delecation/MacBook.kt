package delecation

class MacBook(k:Koprik):Koprik by k{
}