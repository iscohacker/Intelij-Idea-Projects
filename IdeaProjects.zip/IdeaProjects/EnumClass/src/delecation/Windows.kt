package delecation

class Windows : Koprik{
    override fun office() {
        println("Men office dasturlarida vapwe zor ishliman...")
    }

}