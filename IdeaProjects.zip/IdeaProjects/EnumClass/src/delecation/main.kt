package delecation

fun main() {
    val windows = Windows()
    val mac = MacBook(windows)
    mac.office()
}
