package delecation

interface Koprik {
    fun office()
}