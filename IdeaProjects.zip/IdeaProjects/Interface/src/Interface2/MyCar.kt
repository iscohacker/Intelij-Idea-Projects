package Interface2

class MyCar : MyCarInterface{
    override fun yurish() {
        println("Yurmoqda")
    }

    override fun toxtash() {
        println("To'xtab turibdi")
    }
}