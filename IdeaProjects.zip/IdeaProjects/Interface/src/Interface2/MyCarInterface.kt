package Interface2

interface MyCarInterface {
    fun yurish()
    fun toxtash()

}