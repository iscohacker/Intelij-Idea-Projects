package Interface2

fun main() {
    val mycar = MyCar()
    mycar.yurish()
    mycar.toxtash()
}