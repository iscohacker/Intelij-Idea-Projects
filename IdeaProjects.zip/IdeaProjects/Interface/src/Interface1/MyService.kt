package Interface1

class MyService : MyInterfaceService,MyInterfaceService2 {
    override fun addUser() {
        println("Qo'shish")
    }

    override fun showUser() {
        println("Qo'shish")

    }
}