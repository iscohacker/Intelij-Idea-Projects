package Interface1

interface MyInterfaceService {
    fun addUser()
}