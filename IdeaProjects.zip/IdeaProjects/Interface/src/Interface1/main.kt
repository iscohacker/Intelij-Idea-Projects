package Interface1

fun main() {
    val myService = MyService()
    myService.addUser()
    myService.showUser()
}