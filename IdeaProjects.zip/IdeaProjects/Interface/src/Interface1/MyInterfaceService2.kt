package Interface1

interface MyInterfaceService2 {
    fun showUser()
}