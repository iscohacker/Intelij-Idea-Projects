package Vazifa_2

fun main() {
    println(kattasiniTop(4, 5, 9))

}
fun <T : Comparable <T>> kattasiniTop(a: T, b: T, c: T): T {
    if (a >= b && a >= c) {
        return a
    } else if (b >= a && b >= c) {
        return b
    } else {
        return c
    }
}
//Comparable - T turdagi obyektlarni taqqoslash uchun ishlatiladi

/*
nosirov_dev
 */
