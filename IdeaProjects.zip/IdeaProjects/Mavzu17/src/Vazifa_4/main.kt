package Vazifa_4

fun main(args: Array<String>)
{
     val seta = setOf("Kotlin " , "Android ", "Java ")
     val setb = setOf( "I " , "S " , "K " )
     val setc = setOf( 1 ,2 , 3 , 4 )

    for(item in seta)
        print( item )
    println()
    for(item in setb)
        print( item )
    println()
    for(item in setc)
        print( "$item ")
}