package Vazifa_1

fun main() {

    val raqamlar = listOf(1, 2, 3)
    ekrangaChiqar(raqamlar)

    val ismlar = listOf("Iskandar", "Ilmiddin", "Abdulloh" )
    ekrangaChiqar(ismlar)
}
fun <T> ekrangaChiqar(list: List<T>) {
    for (i in list) {
        println(i)
    }
}
/*
nosirov_dev
 */