package Vazifa_3
fun main() {
    val palimarfizmga = Palimarfizm()
    val chaqirga = Chaqir(palimarfizmga)
    chaqirga.print()
}class Palimarfizm{
    fun print() {
        println("Hudo hohlasa hamasi zo'r bo'ladi")
    }
}

class Chaqir( val oziniki: Palimarfizm) {

    fun print()= oziniki.print()
}

/*
nosirov_dev
 */










