package Vazifa_5

fun main() {
    val b = Salomat(10)
    Mashina(b).printMessage()
}

class Salomat(val i: Int) : Salom {
    override fun printMessage() {
        print(i)
    }
}
class Mashina(b: Salom) : Salom by b


interface Salom {
    fun printMessage()
}
