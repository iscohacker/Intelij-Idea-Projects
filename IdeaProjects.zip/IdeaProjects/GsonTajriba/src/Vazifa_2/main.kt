package Vazifa_2

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

fun main() {
    val userList = listOf(
        User(
            1,
            "Leanne Graham",
            "Bret",
            "Sincere@april.biz",
            Address(
                "Kulas Light",
                "Apt. 556",
                "Gwenborough",
                "92998-3874",
                Geo(
                    "-37.3159",
                    "81.1496"
                )
            ),
            "1-770-736-8031 x56442",
            "hildegard.org",
            Company(
                "Romaguera-Crona",
                "Multi-layered client-server neural-net",
                "harness real-time e-markets"
            )

        )
    )

    val gson = Gson()

    val json = gson.toJson(userList)
    println("JSON: $json")

    val type = object : TypeToken<List<User>>() {}.type
    val list: List<User> = gson.fromJson(json, type)
    println("LIST: $list")
}

data class Geo(
    val lat: String,
    val lng: String
)

data class Address(
    val street: String,
    val suite: String,
    val city: String,
    val zipcode: String,
    val geo: Geo
)

data class Company(
    val name: String,
    val catchphrase: String,
    val bs: String
)

data class User(
    val id: Int,
    val name: String,
    val username: String,
    val email: String,
    val address: Address,
    val phone: String,
    val website: String,
    val company: Company
)
