import com.google.gson.Gson

fun main() {
//    val user = User("Iskandar",17)
//    val gson = Gson()
//    val gsonString:String = gson.toJson(user)
//    println(gsonString)

//    val gsonString:String = "{\"name\":\"Iskandar\",\"age\":17}"
//    val gson = Gson()
//    val user:User = gson.fromJson(gsonString,User::class.java)
//    println(user.age)

}
data class User(var name : String,var age : Int)