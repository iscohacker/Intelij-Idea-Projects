import java.util.*

class MyService : MyServiceInterface {

    val list  = arrayOfNulls<User>(100)
    val input = Scanner(System.`in`)
    var sanoq = 0

    override fun addUser() {
        println("Iltimos , ismingizni kiriting: ")
        val name = input.next()
        println("Iltimos , yoshingizni kiriting: ")
        val age = input.nextInt()
        println("Iltimos , telefon raqamingizni kiriting: ")
        val phone = input.next()
        val user = User(name,age,phone)
        list[sanoq] = user
        sanoq++
        println("Foydalanuvchi ma'lumotlar saqlandi 😊")
        println("")
    }

    override fun showUser() {
        if (sanoq==0){
            println("Bo'limda foydanuvchilar yo'q ☢️")
            println("")
        }
        for (i in 0 until sanoq){
            println(list[i])

        }
    }

    override fun deleteUser() {
        println("🗑️ Iltimos , o'chirmoqchi bo'lgan foydalanuvchini tanlang: ")
        for (i in 0 until sanoq){
            println("$i -> ${list[i]} ")
            println("")

        }
            val index = input.nextInt()
        for (i in index until sanoq){
            list[i] = list[i+1]
            println("")
        }
        sanoq--
        println("Foydalanuvchi ma'lumotlar o'chirib tashlandi 😊")
    }

    override fun editUser() {
        println("✏️Iltimos , tahrirlamoqchi bo'lgan foydalanuvchi raqamini kiriting: ")
        for (i in 0 until sanoq){
            println("$i -> ${list[i]}")
            println(" ")
        }
        val index = input.nextInt()
        println("Iltimos , foydalanuvchining yangi ismni kiriting: ")
        val newname = input.next()
        println("Iltimos , foydalanuvchining yangi yoshini kiriting: ")
        val newage = input.nextInt()
        println("Iltimos , foydalanuvchining yangi telefon raqam kiriting: ")
        val newphone = input.next()
        println("")

        list[index] = User(newname,newage,newphone)
        println("Foydalanuvchi ma'lumotlari tahrirlandi va saqlandi 😊")
    }


}