interface MyServiceInterface {
    fun addUser()
    fun showUser()
    fun deleteUser()
    fun editUser()
}