import java.util.*
import kotlin.system.exitProcess

fun main() {
    val input = Scanner(System.`in`)

    val myServie = MyService()

    while (true) {

        if (myServie.sanoq == 0) {
            println(
                "         Xurmatli administrator❗❗❗\n" +
                        "Hali dasturga birorta ham foydalanuvchi qoshilmadi 😊\n" +
                        "Foydalanuvchi qo'shish uchun '1️⃣' ni bosing\n" +
                        "Dasturdan chiqish uchun esa '0️⃣' ni bosing"
            )
            when (input.nextInt()) {
                1 -> myServie.addUser()
                0 -> exitProcess(0)
            }
        }
        println(
            "Iltimos , bo'limlardan birirni tanlang 👇 \n" +
                    "1️⃣->Foydalanuvchilarni qo'shish ➕\n" +
                    "2️⃣->Foydalanuvchilarni ko'rish 👁️\n" +
                    "3️⃣->Foydalanuvchilarni o'chirish 🗑️\n" +
                    "4️⃣>Foydalanuvchi ma'lumotlarini tahrirlash ✏️"
        )

        when (input.nextInt()) {
            1 -> myServie.addUser()
            2 -> myServie.showUser()
            3 -> myServie.deleteUser()
            4 -> myServie.editUser()
        }
    }
}