import java.util.*

fun main() {
    
    val input = Scanner(System.`in`)
    while (true){

        println("1->Tug'ilgan kun ,  2->To'y , 3->Vazifa qilish")
        val n = input.nextInt()

        when(n){

            1-> {

                tugilgankunda()

            }
            2->{

                toyda()

            }
            3->{

                println(doinghomework())

            }
        }
    }
}
fun tugilgankunda(){
    println("Ismingizni kiriting: ")
    val name = Scanner(System.`in`).next()
    println("Yoshingizni kiriting")
    val age = Scanner(System.`in`).nextInt()
    println(tugilgankun(name, age))
    println("Tabrik kiriting: ")
    val tabrik1 = Scanner(System.`in`).next()
    println(tortyiyish(tabrik1))

}
fun toyda(){
    println("1->Zaksga chiqish , 2->Toyona berish, 3->Tabriklash")
    when(Scanner(System.`in`).nextInt()){
        1->{
            println("Ismingizni kiriting: ")
            var name = Scanner(System.`in`).next()
            println("Yoshingizni kiriting")
            var age = Scanner(System.`in`).nextInt()
            if (acceptdrivecar(name , age)){
                println("Yaxshi bo'rib kelinglar")
            }else{
                println("Jarimaga tushib qoldim...")
                qarzsorash(true)
            }
        }
        2->{
            println("Qancha to'yona berasiz")
            var m = Scanner(System.`in`).nextInt()
            println(toyonaberish(m))
        }
        3->{
            println("Ismini yozing: ")
            val name = Scanner(System.`in`).next()
            println("Yoshini kiring: ")
            val age = Scanner(System.`in`).nextInt()
            println(tugilgankun(name, age))

        }
    }
}
fun tortyiyish(tabrik:String):String{
    return "$tabrik\n" +
            "To'rtdan olinlar"
}
fun tugilgankun(name:String , age:Int):String{
    return "Janob,$name sizni $age yoshingiz bilan chin qalbimizdan tabriklaymiz!" +
            "Sizga uzoq umr tilaymiz." +
            "Xurmat bilan sizning dasturingiz."
}

fun toyonaberish(money:Int):String{
    return "To'ylar muborak bo'lsin , Sizga $money to'yona bolsin"
}

fun acceptdrivecar(name:String , age:Int):Boolean{
    return age>=16

}

fun doinghomework():String{
    return "Baxona izlamasdan vazifani bajar..."
}

fun qarzsorash(toparoy: Boolean = false):String{
    if (toparoy){
        return "Sanga qarz yo'q , ishla"
    }else{
        return "mm , Vaqtida qayatrsang , olaver"
    }
}