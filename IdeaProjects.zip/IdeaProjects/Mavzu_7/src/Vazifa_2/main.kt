package Vazifa_2

fun main() {
    val son = 2f
    val natija = ishora(son)
    println("$son = $natija")
}

fun ishora(n:Float): Int {
    return when {
        n<0-> -1
        n>0 -> 1
        else-> 0
    }
}
