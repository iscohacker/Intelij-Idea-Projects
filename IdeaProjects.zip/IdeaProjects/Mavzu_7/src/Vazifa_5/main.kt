package Vazifa_5

import java.util.*

fun main() {
    val input = Scanner(System.`in`)
    print("So'z kiriting, janob: ")
    val soz = input.next()
    println("Natija: "+oxiriga_chiqar(soz))
}
fun oxiriga_chiqar(txt: String): String {
    var natija = ""
    var sana = 0

    for (n in txt) {
        if (n == 'x') {
            sana++
        } else {
            natija += n
        }
    }
    for (i in 1..sana) {
        natija += 'x'
    }

    return natija
}

//
//fun main() {
//    sartirofka("ajxiiaihdnkxxainxa")
//}
//fun sartirofka(str:String){
//    var xlar = ""
//    var boshqa  = ""
//    for (c in str){
//        if (c=='x'){
//            xlar +=c
//        }else{
//            boshqa +=c
//        }
//    }
//    println(boshqa + xlar)
//}