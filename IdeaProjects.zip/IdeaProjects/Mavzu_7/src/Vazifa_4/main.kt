import kotlin.random.Random
fun main() {
    random()
}//rekursiv funksiya
fun random(){
    val random = java.util.Random()
    val n1 = random.nextInt(3)
    val n2 = random.nextInt(3)
    val n3 = random.nextInt(3)
    if (n1==n2 || n2==n3 || n3==n1){
        random()
    }else{
        println(n1)
        println(n2)
        println(n3)
    }
}
