package Vazifa_3

import java.util.*

fun main() {
    val input = Scanner(System.`in`)
    print("Son kiriting: ")
    val n = input.nextInt()
    faktorial(n)
}
fun faktorial(n: Int){
    var n2 = 1
    for (i in 1 until n+1) {
        n2*=i
        println("$n! = $n2")
    }


}



////creator : Iskandarbek Nosirov



//
//fun main() {
//    println(myfucktorial(5))
//}
//fun myfucktorial(a:Int){
//    if (a<=1){
//        return 1
//    }else{
//        return a*myfucktorial(a-1)
//    }
//}