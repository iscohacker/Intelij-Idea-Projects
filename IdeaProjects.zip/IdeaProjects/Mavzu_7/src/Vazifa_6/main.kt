package Vazifa_6

import java.util.*

fun main() {
    val input = Scanner(System.`in`)
    println("So'z kiriting: ")
    val text = input.next()
    println(ajratuvchi(text))
}
fun ajratuvchi(txt:String):String{
    var text = ""
    for (i in txt){
        text += "$i*"
    }
    text =  text.substring(0, text.length-1)
    return text
}