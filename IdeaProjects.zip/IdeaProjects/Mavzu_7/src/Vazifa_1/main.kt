package Vazifa_1

fun main() {

    val raqam = 123456789
    val natija = InvertDigit(raqam)

    println(natija)
}
fun InvertDigit(raqam:Int): Int {
    val raqam1 = raqam.toString().reversed()
    return raqam1.toInt()
}

