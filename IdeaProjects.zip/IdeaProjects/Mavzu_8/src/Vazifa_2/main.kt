package Vazifa_2
fun main() {
    val son = arrayOf(1, 2, 3, 4, 5, 6, 7, 8, 9)
    val n = son.size
    val yangi = IntArray(n)

    for (i in 0 until n - 1) {
        yangi[i] = (son[i] + son[i + 1]) / 2
    }

    yangi[n - 1] = son - 1]

    for (i in yangi.indices) {
        print("${yangi[i]} ")
    }
}
