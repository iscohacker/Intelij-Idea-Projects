package Vazifa_5

fun main() {
    val engkatta2 = arrayOf(25,45,75,95,150,12562,4665568)
    var max1 = -1
    var max2 = -1

    for (num in engkatta2) {
        if (num > max1) {
            max2 = max1
            max1 = num
        } else if (num > max2) {
            max2 = num
        }
    }

    println("Ikkinchi katta son: $max2")
}

