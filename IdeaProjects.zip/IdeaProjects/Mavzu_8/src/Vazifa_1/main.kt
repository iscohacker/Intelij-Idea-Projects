package Vazifa_1

fun main() {
    val sonlar = 123456789
    val son = sonlar.toString().reversed()
    print("Teskarisi: ")
    for (i in son) {
        print(i)
    }
}