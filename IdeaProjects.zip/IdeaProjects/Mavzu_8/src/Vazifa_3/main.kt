package Vazifa_3

//n ta butun sonlardan iborat massiv berilgan. Massivdagi har bir
//toq sonni oxirgi toq songa
//orttiruvchi programma tuzilsin.
//Agar toq sonlar bo'lmasa, massiv
//o'zgarishsiz qoldirilsin.

fun main() {
    val son = arrayOf(1, 2, 3, 4, 5, 6, 7, 8)
    var n = -1

    for (i in son.indices.reversed()) {
        if (son[i] % 2 != 0) {
            n = son[i]
        }
    }

    if (n != -1) {
        for (i in son.indices) {
            if (son[i] % 2 != 0) {
                son[i] = n
            }
        }
    }

    for (element in son) {
        print("$element ")
    }
}

