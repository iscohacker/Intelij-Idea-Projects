package Tajriba

//fun main() {
//    val list = ArrayList<String>()
//    list.add("Iskandar")
////    list.forEach{
////        println(it)
////    }
////    list.contains("Iskandar")
////  list.clear()
//
//}



//fun main() {
//    val list = setOf(12,55,44,12)
//    list.forEach {
//        println(it)
//    }
//}
//dublicate qilish imkoniyat mavjud bolmagan connection

            