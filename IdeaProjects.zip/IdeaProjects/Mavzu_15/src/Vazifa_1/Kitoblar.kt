package Vazifa_1

import java.util.*

class Kitoblar : MyServiceIntervace {
        var input = Scanner(System.`in`)
    override fun kutubhona() {
        while (true) {
            println(
                "Siz hozir kutubxona bo'limidasiz\n" +
                        "Bu yerda kutubxonaga oid malumotlrni topasiz: kitoblar:1245ta , javonlar: 5ta , partalar va stullar: 15ta")
        break
        }
        println(" ")
        println("Bolimlardan birini tanlang:\n" +
                "1->Kutubxona\n" +
                "2->O'quvchilar \n" +
                "3->Kitoblar")
    }


    override fun oquvchi() {
        println("Kutubxonaga a'zo bo'lgan o'quvchilar ro'yxati:")
        println("1->Nosirov Iskandarbek -> Raqamnli qala")
        println("2->O'rinov Ilmiddin -> Atom odatlar")
        println("3->Abdulloh -> Android dasturlash")
        println(" ")
        println("Bolimlardan birini tanlang:\n" +
                "1->Kutubxona\n" +
                "2->O'quvchilar \n" +
                "3->Kitoblar")
    }

    override fun kitoblar() {
        while (true) {
            println("Siz kitoblar bo'limidasiz.")
            println(
                "Janrlardan birini tanlang.\n" +
                        "1->Badiy kitoblar\n" +
                        "2->Detektiv kitoblar\n" +
                        "3->Dramatik kitoblar\n" +
                        "4->Jurnallar\n" +
                        "5->Gazetalar\n" +
                        "6->Bosh menyu")
            println("")
            when (input.nextInt()) {
                1 -> {
                    println(
                        "Kutubxonamizdagi badiy kitoblar ro'yxati: \n" +
                                "1->Abdulla Qodiriy - O'tkan kunlar\n" +
                                "2->Pirimqul Qodirov - Yulduzli tunlar\n" +
                                "3->Said Ahmad - Kiprikda qolgan tong\n" +
                                "4->Tog'ay Murod - Bu dunyoda o'lib bo'lmaydi\n" +
                                "5->Said Ahmad - Tanlangan asarlar")
                    println("")

                }

                2 -> {
                    println(
                        "Kutubxonamizni detektiv kitoblar ro'yxati: \n" +
                                "1->O'lim - bu yolg'iz narsa\n" +
                                "2->Dragon zarbli qiz\n" +
                                "3->Morg ko'chasida qotillik\n" +
                                "4->Qulflangan xona\n" +
                                "5->Roger Ecroydni o'ldirish")
                    println("")
                }
                3-> {
                    println("Kutubxonamizni dramatik kitoblar ro'yxati: \n" +
                            "1->Abdulla Avloniy. Advokatlik osonmi\n" +
                            "2->Abdulla Qahhor. Og'riq tishlar\n" +
                            "3->Abdurauf Fitrat. Abulfayzxon\n" +
                            "4->Erkin A'zam. Farrosh kampirning tushi\n" +
                            "5->Erkin Vohidov. Oltin devor")
                    println("")
                }
                4->{
                    println("Kutubxonamizni jurnallar bo'limidasiz: \n" +
                            "1->“Гелиотехника” журнали\n" +
                            "2->Математика институти бюллетени электрон журнали\n" +
                            "3->Сейсмология муаммолари» журнали")
                    println("")
                }
                5->{
                    println("Tizim kutubxonasining gazetalar bo'limi:\n" +
                            "1->Darakchi gazetasi\n" +
                            "2->Sug'diyona gazetasi\n" +
                            "\n" +
                            "Xoxlasangiz yangiliklarni online kuzatish imkoniyati mavjud\n" +
                            "1->kun.uz\n" +
                            "2->qalampir.uz")
                    println("")
                }
                6->{
                    boshmenyu()

                }
            }
        }
    }
    override fun boshmenyu(){
        main()
    }
}