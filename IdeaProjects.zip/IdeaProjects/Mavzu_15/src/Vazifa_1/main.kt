/*
Kutubxona tizimini yarating. Tizimda kutubxona,
 o'quvchi hamda kitoblar obyektlari bor.
 Kitoblar toifalangan(badiiy, detektiv....).
 \Bu tizimni obyektivni tasvirlab bera oladigan loyiha yarating.
 Imkoniyatlarini kengaytiring.
 */
package Vazifa_1

import java.util.*

fun main() {
    var mybook = Kitoblar()
    var input = Scanner(System.`in`)
    while (true) {
        println(
            "Tizm kutubxonasiga hush kelibsiz\n" +
                    "Bolimlardan birini tanlang:\n" +
                    "1->Kutubxona\n" +
                    "2->O'quvchilar \n" +
                    "3->Kitoblar"
        )
            while (true) {
            when (input.nextInt()) {
                1 -> {
                    mybook.kutubhona()
                }
                2 -> {
                    mybook.oquvchi()
                }
                3 -> mybook.kitoblar()
            }
        }
    }
}

