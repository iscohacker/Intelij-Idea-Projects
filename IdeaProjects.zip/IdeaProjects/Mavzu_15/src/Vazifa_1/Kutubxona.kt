package Vazifa_1

class Kutubxona {
    var kutubxona : String? = null
    var oquvchi : String? = null
    var kitoblar : String? = null

    constructor(kutubxona: String?, oquvchi: String?, kitoblar: String?) {
        this.kutubxona = kutubxona
        this.oquvchi = oquvchi
        this.kitoblar = kitoblar
    }
    override fun toString(): String {
        return "Kutubxona(kutubxona=$kutubxona, oquvchi=$oquvchi, kitoblar=$kitoblar)"
    }
}