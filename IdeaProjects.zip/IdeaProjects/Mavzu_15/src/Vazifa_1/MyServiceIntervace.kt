package Vazifa_1

interface MyServiceIntervace {
    fun kutubhona()
    fun oquvchi()
    fun kitoblar()
    fun boshmenyu()

}