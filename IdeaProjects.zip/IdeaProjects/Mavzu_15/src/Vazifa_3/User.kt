package Vazifa_3

class User {
}