package Vazifa_3

fun main() {
    val succes = Download.Succes()
    downloadFeature(succes)

}
sealed class Download{
    class Succes : Download()
    class Field : Download()
    class Loading : Download()
}
fun downloadFeature(d:Download){
    when(d){
        is Download.Loading-> println("Fayl yuklab olinmoqda...")
        is Download.Succes-> println("Yuklab olish muvoffaqiyatli amalga oshhirildi")
        is Download.Field-> println("Yuklab olish amalga oshmadi")
    }
}