package Vazifa_2

import java.util.*
fun main() {
    var yandex = Yandex()
    println("Assalomu alaykum Yandex taxi xizmatiga xush keldingiz\n" +
            "Tizimga haydovchi yoki yolovchi sifatida kirishingiz mumkin\n" +
            "1->Haydovchi\n" +
            "2->Yo'lovchi")
    var input = Scanner(System.`in`)
    while (true){
        when(input.nextInt()){
            1->{
                yandex.haydovchi()
            }
            2->{
                yandex.yolovchi()
            }
        }
    }
}
