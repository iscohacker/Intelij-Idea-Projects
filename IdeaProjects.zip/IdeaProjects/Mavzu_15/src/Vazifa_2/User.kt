package Vazifa_2

class User {
    var name : String? = null
    var age : Int? = null

    constructor(name: String?, age: Int?) {
        this.name = name
        this.age = age
    }

    override fun toString(): String {
        return "User(name=$name, age=$age)"
    }

}