package Vazifa_2

import java.util.*

class Yandex : MyServiceInterface{
var input=Scanner(System.`in`)
    override fun haydovchi() {
        while (true) {
            println(
                "Haydovchi bo'limlaridan birini tanlang: \n" +
                        "1->Manzilga eltib qo'yish\n" +
                        "2->Pochta yetkazib berish\n" +
                        "3->Bosh menyu")
            when (input.nextInt()) {
                1 -> {
                    println(
                        "Yolovchi qabul qilindi!\n" +
                                "Yo'nalish bo'yicha harakat qilamiz\n" +
                                "Manzilga 10 daqiqada yetib boramiz...")
                    println("")
                }
                2 -> {
                    println(
                        "Pochta qabul qilindi\n" +
                                "Buyurtma 6 daqiqada yetib boradi.")
                    println("")
                }
                3 -> {
                    bowmenyu()
                }
            }
        }
    }
    override fun yolovchi() {
        while (true) {
            println(
                        "Bo'limladan birini tanlang: \n" +
                        "1->Taxi buyurtma berish\n" +
                        "2->Kun narxi\n" +
                        "3->Bosh menyu")
            when(input.nextInt()){
                1->{
                    println("Yandex tizimidagi bosh taxilardan biri bir necha daqiqada sizni topadi.\n" +
                            "Xizmat uchun raxmat")
                    println("")
                }
                2->{
                    println("Bugungi kunda 1km yol haqqi 2000 so'mi tashkil qiladi.")
                    println("")
                }
                3->{
                    bowmenyu()
                }
            }
        }
    }
    override fun bowmenyu(){
        main()
    }
}