package Vazifa_2

interface MyServiceInterface {
    fun haydovchi()
    fun yolovchi()
    fun bowmenyu()
}