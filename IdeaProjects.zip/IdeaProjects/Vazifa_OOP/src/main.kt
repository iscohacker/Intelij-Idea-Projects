fun main() {

    val class11 = Class1("Iskandar", "Oddiy",5.5,11,17)
    println(class11)
    val class12 = Class1("Samandar", "Oddiy",5.5,11,17)
    println(class12)
    val class13 = Class1("Alijon", "Oddiy",5.5,11,17)
    println(class13)
    val class14 = Class1("Valijon", "Oddiy",5.5,11,17)
    println(class14)
    val class15 = Class1("Akkombek", "Oddiy",5.5,11,17)
    println(class15)


    val class21 = Class2("Iskandar","Nosirov","BMW","redmi",17)
    println(class21)
    val class22 = Class2("Samandar","Nosirov","BMW","redmi",17)
    println(class22)
    val class23 = Class2("Alijon","Aliyev","BMW","redmi",17)
    println(class23)
    val class24 = Class2("Valijon","Valiyev","BMW","redmi",17)
    println(class24)
    val class25 = Class2("Iskandar","Nosirov","BMW","redmi",17)
    println(class25)

    val class31 = Class3("Acer","Core i3","UHD",17,)
    println(class31)
    val class32 = Class3("Acer","Core i3","UHD",17,)
    println(class32)
    val class33 = Class3("Acer","Core i3","UHD",17,)
    println(class33)
    val class34 = Class3("Acer","Core i3","UHD",17,)
    println(class34)
    val class35 = Class3("Acer","Core i3","UHD",17,)
    println(class35)



    val class41 = Class4("8gb","AcerBlokSystem","AcerCooling",17)
    println(class41)
    val class42 = Class4("8gb","AcerBlokSystem","AcerCooling",17)
    println(class42)
    val class43 = Class4("8gb","AcerBlokSystem","AcerCooling",17)
    println(class43)
    val class44 = Class4("8gb","AcerBlokSystem","AcerCooling",17)
    println(class44)
    val class45 = Class4("8gb","AcerBlokSystem","AcerCooling",17)
    println(class45)



    val class51 = Class5("13MP","mi Standart Stabilization","Portartiv shtativ",17)
    println(class51)
    val class52 = Class5("13MP","mi Standart Stabilization","Portartiv shtativ",17)
    println(class52)
    val class53 = Class5("13MP","mi Standart Stabilization","Portartiv shtativ",17)
    println(class53)
    val class54 = Class5("13MP","mi Standart Stabilization","Portartiv shtativ",17)
    println(class54)
    val class55 = Class5("13MP","mi Standart Stabilization","Portartiv shtativ",17)
    println(class55)

    val class61 = Class6("Anor","olma","Yer shari",17)
    println(class61)
    val class62 = Class6("Anor","olma","Yer shari",17)
    println(class62)
    val class63 = Class6("Anor","olma","Yer shari",17)
    println(class63)
    val class64 = Class6("Anor","olma","Yer shari",17)
    println(class64)
    val class65 = Class6("Anor","olma","Yer shari",17)
    println(class65)



    val class71 = Class7("Kislorod","Vodorod","Karbonat andigrid",17)
    println(class71)
    val class72 = Class7("Kislorod","Vodorod","Karbonat andigrid",17)
    println(class72)
    val class73 = Class7("Kislorod","Vodorod","Karbonat andigrid",17)
    println(class73)
    val class74 = Class7("Kislorod","Vodorod","Karbonat andigrid",17)
    println(class74)
    val class75 = Class7("Kislorod","Vodorod","Karbonat andigrid",17)
    println(class75)



    val class81 = Class8("Qaatiq jism","Uch burchat tirgak","Qizil rangli obyekt",17)
    println(class81)
    val class82 = Class8("Qaatiq jism","Uch burchat tirgak","Qizil rangli obyekt",17)
    println(class82)
    val class83 = Class8("Qaatiq jism","Uch burchat tirgak","Qizil rangli obyekt",17)
    println(class83)
    val class84 = Class8("Qaatiq jism","Uch burchat tirgak","Qizil rangli obyekt",17)
    println(class84)
    val class85 = Class8("Qaatiq jism","Uch burchat tirgak","Qizil rangli obyekt",17)
    println(class85)



    val class91 = Class9("Quva shaxri","Oltiariq","Farg'ona shaxri , Codial",17)
    println(class91)
    val class92 = Class9("Quva shaxri","Oltiariq","Farg'ona shaxri , Codial",17)
    println(class92)
    val class93 = Class9("Quva shaxri","Oltiariq","Farg'ona shaxri , Codial",17)
    println(class93)
    val class94 = Class9("Quva shaxri","Oltiariq","Farg'ona shaxri , Codial",17)
    println(class94)
    val class95 = Class9("Quva shaxri","Oltiariq","Farg'ona shaxri , Codial",17)
    println(class95)

    val class101 = Class10("nosirov_dev","isco.coder","Windows 11",17)
    println(class101)
    val class102 = Class10("nosirov_dev","isco.coder","Windows 11",17)
    println(class102)
    val class103 = Class10("nosirov_dev","isco.coder","Windows 11",17)
    println(class103)
    val class104 = Class10("nosirov_dev","isco.coder","Windows 11",17)
    println(class104)
    val class105 = Class10("nosirov_dev","isco.coder","Windows 11",17)
    println(class105)

}