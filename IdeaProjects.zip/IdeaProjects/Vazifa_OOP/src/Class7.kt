class Class7 {

    var ism : String? = null
    var age : Int? = null
    var kislorod : String? = null
    var vodorod : String? = null
    var karbonat : String? = null



    constructor()
    constructor(kislorod: String?, vodorod: String?, karbonat: String?, age: Int?) {
        this.kislorod = kislorod
        this.vodorod = vodorod
        this.karbonat = karbonat
        this.age = age
    }


    constructor(ism: String?, kislorod: String?, vodorod: String?, karbonat: String?, age: Int?) {
        this.ism = ism
        this.kislorod = kislorod
        this.vodorod = vodorod
        this.karbonat = karbonat
        this.age = age
    }


    override fun toString(): String {
        return "Class7(Ismi=$ism, Kislorod=$kislorod, Vodorod=$vodorod, Karbonat=$karbonat, Yoshi=$age"
    }
}