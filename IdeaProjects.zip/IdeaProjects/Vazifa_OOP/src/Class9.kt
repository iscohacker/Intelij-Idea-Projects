class Class9 {

    var ism : String? = null
    var age : Int? = null
    var quva : String? = null
    var oltiariq : String? = null
    var fargona : String? = null



    constructor()
    constructor(quva: String?, oltiariq: String?, fargona: String?, age: Int?) {
        this.quva = quva
        this.oltiariq = oltiariq
        this.fargona = fargona
        this.age = age
    }


    constructor(ism: String?, quva: String?, oltiariq: String?, fargona: String?, age: Int?) {
        this.ism = ism
        this.quva = quva
        this.oltiariq = oltiariq
        this.fargona = fargona
        this.age = age
    }


    override fun toString(): String {
        return "Class9(Ismi=$ism, Quva=$quva, Oltiariq=$oltiariq, Farg'ona=$fargona, Yoshi=$age"
    }
}