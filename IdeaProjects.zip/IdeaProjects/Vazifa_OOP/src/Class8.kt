class Class8 {

    var ism : String? = null
    var age : Int? = null
    var jism : String? = null
    var tirgak : String? = null
    var obyekt : String? = null



    constructor()
    constructor(jism: String?, tirgak: String?, obyekt: String?, age: Int?) {
        this.jism = jism
        this.tirgak = tirgak
        this.obyekt = obyekt
        this.age = age
    }


    constructor(ism: String?, jism: String?, tirgak: String?, obyekt: String?, age: Int?) {
        this.ism = ism
        this.jism = jism
        this.tirgak = tirgak
        this.obyekt = obyekt
        this.age = age
    }


    override fun toString(): String {
        return "Class8(Ismi=$ism, Jism=$jism, Tirgak=$tirgak, Obyekt=$obyekt, Yoshi=$age"
    }
}