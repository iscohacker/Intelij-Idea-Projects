class Class2 {
    var ism : String? = null
    var familya : String? = null
    var mashina : String? = null
    var telefon : String? = null
    var age : Int? = null


    constructor()
    constructor(familya: String?, mashina: String?, telefon: String?, age: Int?) {
        this.familya = familya
        this.mashina = mashina
        this.telefon = telefon
        this.age = age
    }


    constructor(ism: String?, familya: String?, mashina: String?, telefon: String?, age: Int?) {
        this.ism = ism
        this.familya = familya
        this.mashina = mashina
        this.telefon = telefon
        this.age = age
    }


    override fun toString(): String {
        return "Class2(Ismi=$ism, Familyasi=$familya, Mashinasi=$mashina, Telefoni=$telefon, Yoshi=$age)"
    }
}