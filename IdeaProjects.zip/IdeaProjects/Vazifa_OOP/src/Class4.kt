class Class4 {

    var ism : String? = null
    var age : Int? = null
    var operatifka : String? = null
    var bloksystem : String? = null
    var cooller : String? = null



    constructor()
    constructor(operatifka: String?, bloksystem: String?, cooller: String?, age: Int?) {
        this.operatifka = operatifka
        this.bloksystem = bloksystem
        this.cooller = cooller
        this.age = age
    }


    constructor(ism: String?, operatifka: String?, bloksystem: String?, cooller: String?, age: Int?) {
        this.ism = ism
        this.operatifka = operatifka
        this.bloksystem = bloksystem
        this.cooller = cooller
        this.age = age
    }


    override fun toString(): String {
        return "Class4(Ismi=$ism, Operatifkasi=$operatifka, Blokli tizimi=$bloksystem, Kulleri=$cooller, Yoshi=$age"
    }
}