class Class3 {
    var ism : String? = null
    var age : Int? = null
    var noutbuk : String? = null
    var protssesor : String? = null
    var videokarta : String? = null



    constructor()
    constructor(noutbuk: String?, protssesor: String?, videokarta: String?, age: Int?) {
        this.noutbuk = noutbuk
        this.protssesor = protssesor
        this.videokarta = videokarta
        this.age = age
    }


    constructor(ism: String?, noutbuk: String?, protssesor: String?, videokarta: String?, age: Int?) {
        this.ism = ism
        this.noutbuk = noutbuk
        this.protssesor = protssesor
        this.videokarta = videokarta
        this.age = age
    }


    override fun toString(): String {
        return "Class3(Ismi=$ism, Noutbuki=$noutbuk, Protssesori=$protssesor, Videokartasi=$videokarta, Yoshi=$age"
    }
}