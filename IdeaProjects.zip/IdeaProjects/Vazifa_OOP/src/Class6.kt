class Class6 {

    var ism : String? = null
    var age : Int? = null
    var meva : String? = null
    var daraxt : String? = null
    var yer : String? = null



    constructor()
    constructor(meva: String?, daraxt: String?, yer: String?, age: Int?) {
        this.meva = meva
        this.daraxt = daraxt
        this.yer = yer
        this.age = age
    }


    constructor(ism: String?, meva: String?, daraxt: String?, yer: String?, age: Int?) {
        this.ism = ism
        this.meva = meva
        this.daraxt = daraxt
        this.yer = yer
        this.age = age
    }


    override fun toString(): String {
        return "Class6(Ismi=$ism, Meva=$meva, Darxti=$daraxt, Yer=$yer, Yoshi=$age"
    }
}