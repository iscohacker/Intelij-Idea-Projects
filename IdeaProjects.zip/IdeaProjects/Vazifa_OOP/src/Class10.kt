class Class10 {

    var ism : String? = null
    var age : Int? = null
    var telegram : String? = null
    var instagramnik : String? = null
    var windows : String? = null



    constructor()
    constructor(telegram: String?, instagramnik: String?, windows: String?, age: Int?) {
        this.telegram = telegram
        this.instagramnik = instagramnik
        this.windows = windows
        this.age = age
    }


    constructor(ism: String?, telegram: String?, instagramnik: String?, windows: String?, age: Int?) {
        this.ism = ism
        this.telegram = telegram
        this.instagramnik = instagramnik
        this.windows = windows
        this.age = age
    }


    override fun toString(): String {
        return "Class10(Ismi=$ism, Telegram=$telegram, Instagram=$instagramnik, Windows=$windows, Yoshi=$age"
    }
}