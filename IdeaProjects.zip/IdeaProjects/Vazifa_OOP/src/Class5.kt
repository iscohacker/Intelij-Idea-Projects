class Class5 {


    var ism : String? = null
    var age : Int? = null
    var kamera : String? = null
    var stabilizator : String? = null
    var shtativ : String? = null



    constructor()
    constructor(kamera: String?, stabilizator: String?, shtativ: String?, age: Int?) {
        this.kamera = kamera
        this.stabilizator = stabilizator
        this.shtativ = shtativ
        this.age = age
    }


    constructor(ism: String?, kamera: String?, stabilizator: String?, shtativ: String?, age: Int?) {
        this.ism = ism
        this.kamera = kamera
        this.stabilizator = stabilizator
        this.shtativ = shtativ
        this.age = age
    }


    override fun toString(): String {
        return "Class5(Ismi=$ism, Kamerasi=$kamera, Stabilizatori=$stabilizator, Shtativi=$shtativ, Yoshi=$age"
    }
}