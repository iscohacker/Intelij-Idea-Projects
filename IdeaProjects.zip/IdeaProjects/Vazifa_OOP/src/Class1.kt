class Class1 {

        var name : String? = null
        var forma : String? = null
        var grade : Double? = null
        var sinf : Int? = null
        var age : Int? = null


        constructor()
        constructor(forma: String?, grade: Double?, sinf: Int?, age: Int?) {
                this.forma = forma
                this.grade = grade
                this.sinf = sinf
                this.age = age
        }


        constructor(name: String?, forma: String?, grade: Double?, sinf: Int?, age: Int?) {
                this.name = name
                this.forma = forma
                this.grade = grade
                this.sinf = sinf
                this.age = age
        }


        override fun toString(): String {
            return "Class1(name=$name, forma=$forma, grade=$grade, sinf=$sinf, age=$age)"
        }
}