import java.util.Scanner

fun valyutaConvert(amount: Double, rate: Double): Double {
    return amount * rate
}

fun main() {
    val input = Scanner(System.`in`)

    print("Iltimos, USD miqdorini kiriting:")
    val usd = input.nextDouble()

    val almashtr = 12683.99

    val uzs = valyutaConvert(usd, almashtr)
    println("$usd USD = $uzs UZS")
}
