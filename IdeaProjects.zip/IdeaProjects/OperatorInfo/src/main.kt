/*
*Date : 10.02.2024
* Creator : Iskandar Nosirov
 */
import java.util.*

fun main() {
    val input = Scanner(System.`in`)
    while (true) {
        println("O'zbek tilini tanlash uchun 1 ni bosing,\n" +
                "Нажмите 2, чтобы выбрать русский язык,\n" +
                "Press 3 to select English"
        )
        when (input.nextInt()) {
            1->{
                println("Qisqa raqamlardan kelayotgan puulik obunalarni o'chirish uchun 1 ni bosing,\n" +
                        "O'z tarif rejangiz haqida qanday ma'lumotga egasiz, bizdagi boshqa tariflar haqida ma'lumot oish uchun 2 bosing,\n" +
                        "Internet paketlar , perezagruzka va xabardor bo'l xizmatiniva boshqa xizmatlarni yoqish yoki o'chirish uchun 3 ni bosing,\n" +
                        "Beepul ilovasi haqida ma'lumot olish va yuklab olish uchun 4 ni bosing,\n" +
                        "Beeline ning ko'ngilochar xizmatlari aynan siz uchun , BeelineTV , Beeline Music. Ma'lumot olish uchun 5 ni bosing,\n" +
                        "Balansizgizdagi pul miqdori , daqiqa , sms va internet trafigi haqida ma'lumot olish uchun hoziroq 6 ni bosing\n" +
                        "Telefon raqamingizni o'zgartirmasdan Beeline o'tish uchun 7 ni bosing\n" +
                        "2024-yil 1-fevralda kuchga kirgan Internet Trafiglaridagi o'zgarishlar haqida ma'lumot olish uchun 8 ni bo'sing\n" +
                        "Operator bilan bo'glanish uchun 0 ni bosing"
                )
                when (input.nextInt()) {
                    1 -> {
                        println("Xabardor Bo'l Xizmatini o'chirish")
                        println("SPORT.UZ Xizmatini o'chirish")
                        println("Pazanda Ximatni o'chirish")
                        when (input.nextInt()) {
                            1 -> {
                                println("Xabardor Bol xizmatini o'chirish uchun sms xabarnoma yuborildi")
                            }
                            2 -> {
                                println("SPORT.UZ xizmatini o'chirish uchun sms xabarnoma yuborildi")
                            }
                            3 -> {
                                println("Pazanda xizmatini o'chirish uchun sms xabarnoma yuborildi")
                            }
                        }
                    }
                    2 -> {
                        println("1.Mening tarifim")
                        println("2.Hamasi zor tarif rejalari")
                        println("3.Status tariflari")
                        println("4.Konstruktor tarifi")
                        when (input.nextInt()) {
                            1->{
                                println("O'z ta'rifingiz va tatrif reja oyning qaysi kuni to'ldirisj kerakligi haqida malumot sms tarzda jo'natildi ")
                            }
                            2->{
                                println("Hammasi ZO'R 1,\n+" +
                                        "Hammasi ZO'R 2,\n+" +
                                        "Hammasi ZO'R 3,\n" +
                                        "Hammasi ZO'R 4"
                                )
                            }
                            3->{
                                println("1.Status Silver\n" +
                                        "2.Status Gold\n" +
                                        "3.Status Platinum")
                            }
                            4->{
                                println("Konstruktor tarifi haqida malumot olish va unga bog'lanish uchun  Beeline Uzbekistan ilovasini yuklab olish havolasi yuborildi")
                            }
                        }
                    }
                    3->{
                        println("Internet Paktelar va ulani narxlari haqida sms xabarnoma olish uchun 1 ni bosing,\n" +
                                "Perezagruzka xizmati haqida malumot olish uchun 2 ni bosing,\n" +
                                "Ishonchli to'lov xizmati haqida sms xabarnoma olish uchun 3 ni bosing,\n" +
                                "Xabardor bo'l xizmatini yo'qish va ochirish boyicha sms xabarnoma olish uchun 4 ni bosing"
                        )
                        when(input.nextInt()){
                            1->{
                                println("Internet paketlar narxlari haqidagi sms xabarnoma sms tarzda yuborildi")
                            }
                            2->{
                                println("Perezagrzuka xizmati haqida to'liq ma'lumot olish va undan qay tartibda foydalanish qollanmasi sms tarzda yuborildi")
                            }
                            3->{
                                println("Ishonchli to'lov xizmatidan foydalanish USSD buyruqlar ro'yxati sms tarzda yuborildi")
                            }
                            4->{
                                println("Xabardor bo'l xizmati Beelinedagi barcha eng so'ngi yangiliklarni birinchi bo'lib o'qing. Xizmatni faollashtirish uchun USSD buyruqlar sms tarzda yuborildi")
                            }
                        }
                    }
                    4->{
                        println("BePul ilovasini yuklash havolasini olish uchun 1 ni bosing,\n" +
                                "Bu haqida ma'lumot olish uchun 2 ni bosing"
                        )
                        when(input.nextInt()){
                            1->{
                                println("BePul ilovasini yuklab olish uchun havola sms tarzda yuborildi!")
                            }
                            2->{
                                println("BePul xizmati va xarajatlani bepul  =orqali amalga oshirish tartib qoidalari sms tarzda yuborildi")
                            }
                        }
                    }
                    5->{
                        println("BeelineTV ilovasini yuklash havolasini olish va bu haqida ma'lumot olish uchun 1 ni bosing,\n" +
                                "Beeline Music ilovasini yuklash havolasi va bu haqida ma'lumot olish uchun 2 ni bosing"
                        )
                        when(input.nextInt()){
                            1->{
                                println("BeelineTV ilovasini yuklab olish havolasi sms tarzda yuborildi!")
                            }
                            2->{
                                println("Beeline Music ilovasini yuklab olish uchun havola sms tarzda yuborildi")
                            }
                        }
                    }
                    6->{
                        println("Balansizngiz , daqiqalaringiz va sms qoldiqlari haqida sms xabarnoma yuborildi")
                    }
                    7->{
                        println("siz o'z telefon raqamingizni ozgartirmasdan Beeline ga a'zo bolish uchun 0697 telefon raqamiga ariza topshirishingiz talab qilinadi")
                    }
                    8->{
                        println("Umumiy trafik,GB- 10 . 20 . 30 . 50 . 75 . 100 .150\n" +
                                "Tungi trafik, GB-5.10.15.25.38.50.75\n" +
                                "Xizmat narxi/ so’m-50000.70000.85000.100000.120000.130000.150000.\n" +
                                "Amal qilish muddati- Barchasi 30 kundan\n"
                        )
                    }
                    0->{
                        println("Xizmat sifatini yaxshilash maqsadida operator bilan kechadigan suxbat yozib olinishi mumkin , operator javobini kuting...")
                    }
                }
            }
            2->{
                println("Нажмите 1, чтобы отказаться от подписки на короткие номера,\n" +
                        "Откуда вы знаете о своем тарифном плане, нажмите 2, чтобы получить информацию о других наших тарифах,\n" +
                        "Нажмите 3, чтобы включить или отключить интернет-пакеты, перезагрузку и быть в курсе сервисных и других услуг,\n" +
                        "Нажмите 4, чтобы узнать о приложении Beepul и загрузить его,\n" +
                        "Развлекательные услуги Билайн специально для Вас, БилайнТВ, Билайн Музыка. Для получения информации нажмите 5,\n" +
                        "Нажмите 6 сейчас, чтобы получить информацию о сумме денег на вашем балансе, минутах, СМС и интернет-трафике\n" +
                        "Чтобы перейти на Билайн без смены номера телефона, нажмите 7\n" +
                        "Нажмите 8, чтобы получить информацию об изменениях в интернет-трафике с 1 февраля 2024 г.\n" +
                        "Нажмите 0 для связи с оператором"
                )
                when (input.nextInt()) {
                    1 -> {
                        println("1.Отключить службу уведомлений")
                        println("2.Отключить службу SPORT.UZ")
                        println("3.Отключить Химат в Пазанде")
                        println("4.Служба готовки отключена!")
                        when (input.nextInt()) {
                            1 -> {
                                println("Отправлено SMS-уведомление для отключения службы Notify Bol")
                            }
                            2 -> {
                                println("Отправлено SMS-уведомление для отключения службы SPORT.UZ")
                            }
                            3 -> {
                                println("Отправлено смс-уведомление об отключении службы готовки")
                            }
                        }
                    }
                    2 -> {
                        println("1.Моя оценка")
                        println("2.Все планы жесткого плана")
                        println("3.Несколько тарифов мощности")
                        println("4.Скорость конструктора")
                        when (input.nextInt()) {
                            1->{
                                println("Ваше описание и информация о том, в какой день месяца для заполнения плана описания отправлено по SMS ")
                            }
                            2->{
                                println("Все ОТЛИЧНО 1,\n+" +
                                        "Все ОТЛИЧНО 2,\n+" +
                                        "Все ОТЛИЧНО 3,\n" +
                                        "Всё ОТЛИЧНО 4")
                            }
                            3->{
                                println("1.Серебряный статус\n" +
                                        "2. Статус Золотой\n" +
                                        "3.Статус Платиновый")
                            }
                            4->{
                                println("Отправлена ссылка на скачивание приложения Beeline Узбекистан для получения информации о тарифе конструктора и связи с ним")
                            }
                        }
                    }
                    3 -> {
                        println("Нажмите 1, чтобы получать смс-уведомления об интернет-пакетах и ценах на Улан,\n" +
                                "Нажмите 2, чтобы получить информацию об услуге Перезагрузка,\n" +
                                "Нажмите 3, чтобы получить SMS-уведомление об услуге безопасных платежей,\n+" +
                                "Нажмите 4, чтобы получить SMS-уведомление об удалении и отключении услуги Be Notified"
                        )
                    }
                    4 -> {
                        println("Нажмите 1, чтобы получить ссылку для скачивания приложения BePul,\n" +
                                "Нажмите 2, чтобы узнать об этом"
                        )
                    }
                    5 -> {
                        println("Нажмите 1, чтобы получить ссылку для скачивания приложения BeelineTV и информацию о нем,\n+" +
                                "Ссылка для скачивания приложения Beeline Music и нажмите 2, чтобы получить информацию о нем"
                        )
                    }
                    6 -> {
                        println("Нажмите 1, чтобы получить смс-уведомление об оставшемся балансе, минутах и смс")
                    }
                    7 -> {
                        println("чтобы стать участником Билайн без смены номера телефона, необходимо подать заявку на номер телефона 0697")
                    }
                    8 -> {
                        println("Общий трафик, ГБ- 10.20.30.50.75.100.150\n" +
                                "Ночное движение, ГБ-5.10.15.25.38.50.75\n" +
                                "Цена услуги/сум-50000.70000.85000.100000.120000.130000.150000.\n" +
                                "Срок действия — все 30 дней\n"
                        )
                    }
                    0 -> {
                        println("В целях улучшения качества обслуживания разговор с оператором может быть записан, дождитесь ответа оператора...")
                    }
                }
            }
            3->{
                println("Press 1 to unsubscribe from short numbers,\n" +
                        "How do you know about your tariff plan, click 2 to get information about our other tariffs,\n" +
                        "Press 3 to enable or disable Internet packages, perezagruzka and be informed service and other services,\n" +
                        "Click 4 to learn about and download the Beepul app,\n" +
                        "Beeline's entertainment services are just for you, BeelineTV, Beeline Music. Click 5 for information,\n" +
                        "Press 6 now to get information about the amount of money, minutes, SMS and internet traffic on your balance\n" +
                        "Press 7 to switch to Beeline without changing your phone number\n" +
                        "Press 8 for information on changes in Internet Traffic effective February 1, 2024\n" +
                        "Press 0 to connect to an operator"
                )
                when (input.nextInt()) {
                    1 -> {
                        println("1.Disable Notify Service")
                        println("2.Disable SPORT.UZ Service")
                        println("3.Disable Khimat in Pazanda")
                        when (input.nextInt()) {
                            1 -> {
                                println("An SMS notification has been sent to disable the Notify Bol service")
                            }
                            2 -> {
                                println("An SMS notification has been sent to disable the SPORT.UZ service")
                            }
                            3 -> {
                                println("An sms notification has been sent to disable the cook service")
                            }
                        }
                    }
                    2 -> {
                        println("1.My Rate")
                        println("2.All hard plan plans")
                        println("3.Status Rates")
                        println("4.Constructor Rate")
                        when (input.nextInt()) {
                            2 -> {
                                println("Everything is GREAT 1,\n+" +
                                        "Everything is GREAT 2,\n+" +
                                        "Everything is GREAT 3,\n" +
                                        "Everything is GREAT 4"
                                )
                                when (input.nextInt()) {
                                    1->{
                                        println("Information on which day of the month to fill in your description and tariff plan has been sent by SMS ")
                                    }
                                    2->{
                                        println("Everything is GREAT 1,\n+" +
                                                "Everything is GREAT 2,\n+" +
                                                "Everything is GREAT 3,\n" +
                                                "Everything is GREAT 4")
                                    }
                                    3->{
                                        println("1.Status Silver\n" +
                                                "2. Status Gold\n" +
                                                "3.Status Platinum")
                                    }
                                    4->{
                                        println("A link to download the Beeline Uzbekistan application has been sent to get information about the constructor's tariff and contact it")
                                    }
                                }
                            }
                            3 -> {
                                println("Press 1 to receive SMS notifications about Internet Packages and Ulan prices,\n" +
                                        "Click 2 to get information about the Perezagruzka service,\n+" +
                                        "Press 3 to receive SMS notification about secure payment service,\n+" +
                                        "Press 4 to receive an SMS notification to delete and disable the Be Notified service"
                                )
                            }
                            4 -> {
                                println("Click 1 to get BePul app download link,\n" +
                                        "Click 2 to learn about this"
                                )
                            }
                            5 -> {
                                println("Click 1 to get a link to download the BeelineTV application and get information about it,\n+" +
                                        "Beeline Music app download link and click 2 for information"
                                )
                            }
                            6 -> {
                                println("Press 1 to receive sms notification about your balance, minutes and sms remaining")
                            }
                            7 -> {
                                println("you are required to apply for a 0697 phone number to become a member of Beeline without changing your phone number")
                            }
                            8 -> {
                                println("General traffic, GB- 10 . 20 . 30 . 50 . 75 . 100 . 150\n" +
                                        "Night traffic, GB-5.10.15.25.38.50.75\n" +
                                        "Service price/ soum-50000.70000.85000.100000.120000.130000.150000.\n" +
                                        "Expiry - All 30 days\n"
                                )
                            }
                            0 -> {
                                println("In order to improve the quality of service, the conversation with the operator may be recorded, wait for the operator's response...")
                            }
                        }
                    }
                }
            }
        }
    }
}
//Creator : Iskandarbek Nosirov