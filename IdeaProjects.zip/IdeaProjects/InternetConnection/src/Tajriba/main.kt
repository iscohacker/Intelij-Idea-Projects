package Tajriba

import java.net.HttpURLConnection
import java.net.URL
fun main() {
    //link go to
    val link = "http://cbu.uz/uzc/arkhiv-kursov-valyut/json/"
    val connection:HttpURLConnection = URL(link).openConnection() as HttpURLConnection
    val inputStream = connection.inputStream
    val bufferReader = inputStream.bufferedReader()

    var gsonString = ""

    for (s in bufferReader.readLines()){
        gsonString += s
    }
    println(gsonString)
}
