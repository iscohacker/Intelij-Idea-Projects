package Vazifa
import java.net.HttpURLConnection
import java.net.URL
import java.util.*

fun main(){
    val myService = MyService()

    while (true){
        println("1-> So'mdan valyutaga\n" +
                "2-> Valyutadan so'mga")
        when(Scanner(System.`in`).nextInt()){
            1-> myService.somdanValyutaga()
            2-> myService.valyuatadanSomga()
        }
    }
}

