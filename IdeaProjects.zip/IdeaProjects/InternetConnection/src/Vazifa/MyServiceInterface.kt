package Vazifa

interface MyServiceInterface {
    fun getMoneyList():List<MyMoney>
    fun somdanValyutaga()
    fun valyuatadanSomga()
}