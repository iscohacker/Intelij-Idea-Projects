package Vazifa

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type
import java.net.HttpURLConnection
import java.net.URL
import java.util.*

class MyService : MyServiceInterface {
    val input = Scanner(System.`in`)
    override fun getMoneyList(): List<MyMoney> {
        val link = "http://cbu.uz/uzc/arkhiv-kursov-valyut/json/"
        val connection: HttpURLConnection = URL(link).openConnection() as HttpURLConnection
        val inputStream = connection.inputStream
        val bufferReader = inputStream.bufferedReader()

        var gsonString = ""

        for (s in bufferReader.readLines()) {
            gsonString += s
        }
        val type = object : TypeToken<List<MyMoney>>() {}.type
        val list = Gson().fromJson<List<MyMoney>>(gsonString, type)
        return list
    }

    override fun somdanValyutaga() {
        println("Valyutani tanlang: ")
        val list = getMoneyList()
        for (i in 0 until list.size) {
            println("$i -> ${list[i].CcyNm_UZ}")
        }
        val index = input.nextInt()
        println("So'm miqdorini kiriting: ")
        val som = input.nextInt()
        val oneDollar = list[index].Rate.toDouble()
        val valyuta = (som / oneDollar)
        println("$som so'm = $valyuta ${list[index].CcyNm_UZ}")
    }

    override fun valyuatadanSomga() {
        println("Valyutani tanlang: ")
        val list = getMoneyList()
        for (i in 0 until list.size) {
            println("$i -> ${list[i].CcyNm_UZ}")
        }
        val index = input.nextInt()
        println("Valyuta miqdorini kiriting: ")
        val som = input.nextInt()
        val oneDollar = list[index].Rate.toDouble()
        val valyuta = (som * oneDollar)
        println("$som  ${list[index].CcyNm_UZ} = $valyuta so'm")
    }

}