package SocialMedia

class Data {
    var name : String?= null
    var username:String?=null
    var phoneNumber : String? = null


    constructor(name: String?, username: String?, phoneNumber: String) {
        this.name = name
        this.username = username
        this.phoneNumber = phoneNumber
    }

    override fun toString(): String {
        return "Info User : Name:$name, UserName:$username, PhoneNumber:$phoneNumber"
    }

}