package SocialMedia

import java.util.*

class User : MyServiceInterface{

    var input = Scanner(System.`in`)
    var list = arrayOfNulls<Data>(10)
    var sanoq = 0
    var like = 0
    var posts = 0
    var postText :String = ""

    override fun addUser() {
        println("    Tizimga foydalanuvchi qo'shish")
        println("")
        println("Ismingizni kiriting: ")
        var name = input.next()
        println("Username kiriting: ")
        var username = input.next()
        println("Telefon raqamingizni kiriting: ")
        var phoneNumber = input.next()
        var user = Data(name,username,phoneNumber)

        list[sanoq] = user
        sanoq++
        println("Ma'lumotlar saqlandi.")
    }

    override fun showUser() {
        if (sanoq==0){
            println("Hozirda hech qanday foydalanuvchi yo'q!")
        }
        for (i in 0 until sanoq) {
            println("$i -> ${list[i]}, Like: $like , Posts: $posts : $postText")
        }
    }

    override fun deleteUser() {
        if (sanoq==0){
            println("Hozirda hech qanday foydalanuvchi yo'q!")
        }
        for (i in 0 until sanoq) {
            println("$i -> ${list[i]} , Like: $like , Posts: $posts : $postText")
        }
        println("O'chirmoqchi bo'lgan foydalanuvchi raqamini kiriting: ")
        val index = input.nextInt()
        for (i in index until sanoq){
            list[i] = list[i+1]
        }
        sanoq--
        println("Foydalanuvchi o'chirildi.")
    }

    override fun editUser() {

        println("Tahrirlamoqchi bo'lgan foydalanuvchini kiriting: ")
        for (i in 0 until sanoq) {
            println("$i -> ${list[i]}, Like: $like , Posts: $posts : $postText")
        }
        val index = input.nextInt()
        println("Yangi foydalanuvchi ismini kiriting: ")
        var newName = input.next()
        println("Yangi foydalanuvchi userNamesini kiritin: ")
        var newUserName = input.next()
        println("Yangi foydalanuvchi telefon raqamini kiriting: ")
        var newPhoneNumber = input.next()
        var like = 0

        list[index] = Data(newName,newUserName,newPhoneNumber)
        println("Foydalanuvchi ma'lumotlari tahrirlandi.😊")
    }


    override fun like() {
        if (sanoq==0){
            println("Tizimga hech qanday foydalanuvchi kirmagan")
            main()
        }
        println("Qaysi foydalanuvchiga layk bossasiz: ")

        for (i in 0 until sanoq) {
            println("$i -> ${list[i]} , Like: $like , Posts: $posts : $postText")
        }
        val index = input.nextInt()
        like++
        println("Like bosdingiz:${list[index]} , Like: $like , Posts: $posts : $postText")


    }
    override fun posts(){
        if (sanoq==0){
            println("Tizimga hech qanday foydalanuvchi kirmagan")
            main()
        }
        println("Qaysi foydalanuvchi nomidan post qoyasiz: ")

        for (i in 0 until sanoq) {
            println("$i -> ${list[i]} $i -> ${list[i]}, Like: $like , Posts: $posts : $postText ")
        }

        val index = input.nextInt()
        posts++
        println("Iltimos post yozing: ")
        var input = Scanner(System.`in`)

        postText = input.nextLine()
        println("Post qoyildi :${list[index]} $like ta like, $posts ta post : $postText ")
    }
}