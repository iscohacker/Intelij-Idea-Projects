package SocialMedia

import java.util.*

fun main() {
    var input = Scanner(System.`in`)
    var users = User()

    while (true){
        println(
                "1->Qo'shish\n" +
                "2->Ko'rish\n" +
                "3->O'chirish\n" +
                "4->Tahrirlash\n" +
                        "5->Like bosish\n" +
                        "6->Post qo'yish")
        when(input.nextInt()) {
            1->{
                users.addUser()
            }
            2->{
                users.showUser()
            }
            3->{
                users.deleteUser()
            }
            4->{
                users.editUser()
            }
            5->{
                users.like()
            }
            6->{
                users.posts()
            }
        }
    }
}
/*
Iskandarbek Nosirov
23.04.2024-yilda
soat : 14:50 da tugatildi
 */