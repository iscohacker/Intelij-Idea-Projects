package SocialMedia

interface MyServiceInterface {
    fun addUser()
    fun showUser()
    fun deleteUser()
    fun editUser()
    fun like()
    fun posts()

}