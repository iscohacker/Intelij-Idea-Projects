package Payme

import java.util.*
import kotlin.system.exitProcess

fun main() {
var sanoq = 0
    val input = Scanner(System.`in`)

    val pul = Pul()
    while (true) {
        println(
                    "╭━━━━━━━━━━━━━━━━━━━━━━━━━╮\n" +
                    "┃⠀⠀⠀        ●══⠀          ┃\n" +
                    "┃       Payme Consol      ┃\n" +
                    "┃                         ┃\n" +
                    "┃                         ┃\n" +
                    "┃  1️⃣ Karta qo'shish      ┃\n" +
                    "┃  2️⃣ Kartalarim          ┃\n" +
                    "┃⠀⠀3️⃣ Pul o'tkazish       ┃\n" +
                    "┃⠀⠀4️⃣ Monitoring    ⠀     ┃\n" +
                    "┃⠀⠀5️⃣⠀Chiqish⠀       ⠀    ┃\n" +
                    "┃⠀⠀      ⠀                ┃\n" +
                    "┃⠀⠀⠀         ⠀    ⠀       ┃\n" +
                    "┃⠀⠀⠀⠀    ⠀                ┃\n" +
                    "┃_________________________┃\n" +
                    "┃⠀⠀⬅️⠀⠀  ⏺️     ⏏️ ┃\n" +
                    "╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
        )
        when(input.nextInt()){
            1->{
                pul.addCard()
            }
            2->{
                pul.showCards()
            }
            3->{
                pul.pulOtkaz()
            }
            4->{
                pul.monitoring()
            }
            5->{
                exitProcess(1)
            }
        }
    }
}

class Pul:MyServiceInterface{
    var input = Scanner(System.`in`)
    var list = arrayOfNulls<Cards>(100)
    val monoList = arrayOfNulls<Monitoring>(100)
    var sanoq = 0

    override fun addCard() {
        println("Iltmos , karta raqamini kiriitng: ")
        val cardNum = input.next()
        println("Iltimos ,karta amal qilish muddatini kiriting: ")
        val amalQil = input.next()
        println("Karta egasini ismi:")
        val nameCard = input.next()
        println("Kartani hozirgi balansini kiriting: ")
        val balans = input.next()
        val karta = Cards(cardNum, amalQil,nameCard,balans)
        list[sanoq] = karta
        sanoq++
        println("Karta ma'lumotlari saqlandi!")
        println(" ")
    }

    override fun showCards() {
        if (sanoq==0){
            println("Hozirda sizda hech qanday karta qo'shilmagan!")
        }
        for (i in 0 until sanoq) {
            println(list[i])
        }
    }

    override fun pulOtkaz() {
            if (sanoq == 0) {
                println("Sizda hali karta mavjud emas uni karta qo'shish bo'limidan qoshing.")
                main()
            }
            println("Pul o'tkaziladigan karta raqamini kiritng: ")
            val otkazishCard = input.next()
            println("Summani kiriting: ")
            val summa = input.next()
            val kartaga = Monitoring(otkazishCard, summa)
            monoList[sanoq] = kartaga

            sanoq++
            println("Pul muvoffaqiyatli o'tkazildi, uni Monitoring bo'limidan ko'rishingiz mumkin!😊")
    }

    override fun monitoring() {
        if (sanoq==0){
            println("Hozircha hech qanday o'tkazma mavjud emas")
            main()
        }
        for (i in 0 until sanoq) {
            println(monoList[i])
        }

    }

}


open class Monitoring{
    var otkazmas : String? = null
    var summas : String? = null

    constructor(otkazmas: String?, summa: String?) {
        this.otkazmas = otkazmas
        this.summas = summa
    }

    override fun toString(): String {
        return "Monitoring( Ushbu kartaga $otkazmas , $summas so'm pul o'tkazildi.)"
    }

}


class Cards {
    var cardNumber: String? = null
    var amalQilish: String? = null
    var nameCard : String? = null
    var balanss : String? = null

    constructor(cardNum: String, amalQil: String?,name:String?,balans:String?) {
        this.cardNumber = cardNum
        this.amalQilish = amalQil
        this.nameCard  = name
        this.balanss = balans
    }

    override fun toString(): String {
        return  "╭━━━━━━━━━━━━━━━━━━━━━━━━━╮\n" +
                "⠀Name:${nameCard}⠀⠀       \n" +
                " Card Num:${cardNumber}           \n" +
                " Data:${amalQilish}           \n" +
                " Balance:${balanss} so'm           \n"+
                "╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
}
}

interface MyServiceInterface{
    fun addCard()
    fun showCards()
    fun pulOtkaz()
    fun monitoring()
}
/*
Iskandarbek Nosirov
 20.04.2024-yil
 */