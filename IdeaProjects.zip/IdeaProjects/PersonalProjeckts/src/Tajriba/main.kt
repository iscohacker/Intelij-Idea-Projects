package Tajriba
//import java.util.Scanner
//
//fun main() {
//    val scanner = Scanner(System.`in`)
//    println("Iltimos, so'zni kiriting:")
//    val originalWord = scanner.next()
//
//    println("Shifrlash uchun 1 ni, o'zgartirish uchun 2 ni tanlang:")
//    val choice = scanner.nextInt()
//
//    val resultWord = if (choice == 1) {
//        // Shifrlash
//        val shiftedWord = originalWord.map { it + 1 }.joinToString("")
//        shiftedWord
//    } else {
//        // O'zgartirish
//        val shiftedWord = originalWord.map { shift(it) }.joinToString("")
//        shiftedWord
//    }
//
//    println("Natija: $resultWord")
//}
//
//fun shift(c: Char): Char {
//    val ozbekAlifbo = "abdefghijklmnopqrstuvxyz"
//    val index = ozbekAlifbo.indexOf(c.toLowerCase())
//    return if (index != -1) {
//        val nextIndex = (index - 1) % ozbekAlifbo.length
//        if (c.isUpperCase()) ozbekAlifbo[nextIndex].toUpperCase() else ozbekAlifbo[nextIndex]
//    } else c
//}



import java.util.*

fun main() {
    val scanner = Scanner(System.`in`)
    val responses = mapOf(
        "salom" to "Salom, qanday yordam berishim mumkin?",
        "qandaysiz" to "Men botman, lekin siz qandaysiz?",
        "rahmat" to "Arzimaydi!"
    )

    while (true) {
        print("Savolingizni kiriting: ")
        val input = scanner.nextLine().toLowerCase()

        if (responses.containsKey(input)) {
            println(responses[input])
        } else {
            println("Kechirasiz, men hozircha faqat cheklangan savollarga javob berishim mumkin.")
        }
    }
}
