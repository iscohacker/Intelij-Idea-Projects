class Author {
    var name : String? = null
    get() = field
    var email : String? = null
    get() = field
    set(value) {
        field = value
    }
    var gender : Char? = null
    get() = field

    constructor(name: String?, email: String?, gender: Char?) {
        this.name = name
        this.email = email
        this.gender = gender
    }
    fun getGender():Char{
        return '4'
    }

    override fun toString(): String {
        return "Author(name=$name, email=$email, gender=$gender)"
    }


}