class Book {
        var name:String? = null
            get() = field
        var author: Author = Author("Iskandar","iskandarattak@gmail.com",'E')
            get() = field
        var price:Double? = null
        var qty:Int = 0
        get() = field
        set(value) {
            field = value
        }

    override fun toString(): String {
        return "Book(name=$name, author=$author, price=$price, qty=$qty)"
    }

}