class Account {
    var id : Int? = null
    get() = field
    var name : String? = null
    get() = field
    var balance : Int = 0
    get() = field

    constructor(id: Int?, name: String?) {
        this.id = id
        this.name = name


    }

    constructor(id: Int?, name: String?, balance: Int) {
        this.id = id
        this.name = name
        this.balance = balance
    }


    fun credit(amount:Int):Int{
        var amount = 5
        return 10


    }
    fun debit(amount:Int):Int{
        var amount = 15
        return 10

    }

    override fun toString(): String {
        return "Account(id=$id, name=$name, balance=$balance)"
    }


}