class Restangle {
    var lenght : Float? = null
    get() = field
    set(value) {
        field = value
    }
    var widht : Float? = null
    get() = field
    set(value) {
        field = value
    }

    constructor(lenght: Float?, widht: Float?) {
        this.lenght = lenght
        this.widht = widht
    }

    fun getArea():Double{
        return 0.0
    }
    fun getPeremetr():Double{
        return 0.0
    }

    override fun toString(): String {
        return "Restangle(lenght=$lenght, widht=$widht)"
    }


}