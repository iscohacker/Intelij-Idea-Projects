class Employee {
    var id : Int? = null
    get() = field
    var firstName : String? = null
        get() = field
    var lastName : String?  = null
        get() = field
    var salary : Int? = null
    get() = field
    set(value) {
        field = value
    }

    constructor(id: Int?, firstName: String?, lastName: String?, salary: Int?) {
        this.id = id
        this.firstName = firstName
        this.lastName = lastName
        this.salary = salary
    }
    fun getName():String{
        return "$firstName $lastName"

    }
    fun getAnnualSalary():Int{
        return 12*salary!!

    }

    fun raiseSalary(percent:Int):Int{
        return ((1+percent/100.0)*salary!!).toInt()
    }

    override fun toString(): String {
        return "Employee(id=$id, firstName=$firstName, lastName=$lastName, salary=$salary)"
    }

}