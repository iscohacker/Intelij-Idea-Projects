fun main() {
    val iskandar = Employee(1,"Iskandar","Nosirov",5000)
    println(iskandar)

    val restangle = Restangle(4f,6f)
    println(restangle)

    val circle = Circle(1.0,"Qizil")
    println(circle)

    val account = Account(1,"Iskandar",1)
    println(account)

    val author = Author("Iskandarbek","iskandarattak@gmail.com",'E')
    println(author)




}