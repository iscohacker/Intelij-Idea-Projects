import java.io.File

fun main() {
    val asosiyPapka = File("Asosiy Papka")
    asosiyPapka.mkdir()

    for (i in 1..2) {
        val birinchiPapka = File(asosiyPapka, "Birinchi papka ")
        birinchiPapka.mkdir()

        for (i in 1..2) {
            val ikkinchiPapka = File(birinchiPapka, "Ikkinchi papka ")
            ikkinchiPapka.mkdir()

            for (i in 1..3) {
                val uchinchiPapka = File(ikkinchiPapka, "Uchinchi papka ")
                uchinchiPapka.mkdir()

                for (i in 1..4) {
                    val file = File(uchinchiPapka, "Name.txt")
                    file.writeText("Nosirov Iskandarbek (Developer)")
                }
            }
        }
    }
}
