package Vazifa_1

open class Restangle : Shape{
    var width : Double = 1.0
    get() = field
    set(value) {
        field = value
    }
    var lenght : Double = 1.0
    get() = field
    set(value) {
        field = value
    }

    constructor()
    constructor(color: String, filled: Boolean, width: Double, lenght: Double) : super(color, filled) {
        this.width = width
        this.lenght = lenght
    }
    fun getArea():Double{
        return 2.0
    }
    fun getPerimetr():Double{
        return 2.0
    }

    override fun toString(): String {
        return "Restangle(width=$width, lenght=$lenght)"
    }


}