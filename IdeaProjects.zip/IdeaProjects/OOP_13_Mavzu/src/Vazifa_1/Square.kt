package Vazifa_1

class Square : Restangle {
    var side : Double = 0.0
    get() = field
    set(value) {
        field = value
    }
    constructor()
    constructor(color: String, filled: Boolean, width: Double, lenght: Double, side: Double) : super(
        color,
        filled,
        width,
        lenght
    ) {
        this.side = side
    }

    override fun toString(): String {
        return "Square(side=$side)"
    }


}