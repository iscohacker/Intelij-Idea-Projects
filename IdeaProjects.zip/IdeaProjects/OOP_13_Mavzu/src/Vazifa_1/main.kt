package Vazifa_1

fun main() {
    val shapee = Shape("Qizil",true)
    println(shapee)

    val circlee = Circle("Sariq",true,1.0)
    println(circlee)

    val restanglee = Restangle("Yashil",false,1.0,2.0)
    println(restanglee)

    val squaree = Square("Yashil",true,2.0,1.0,5.0)
    println(squaree)
}