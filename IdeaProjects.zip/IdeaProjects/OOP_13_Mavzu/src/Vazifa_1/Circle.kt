package Vazifa_1

class Circle : Shape {
    var radius : Double = 1.0
    get() = field
    set(value) {
        field = value
    }
    constructor()

    constructor(color: String, filled: Boolean, radius: Double) : super(color, filled) {
        this.radius = radius
    }

    fun getArea():Double{
        return 1.0
    }
    fun getPerimetr():Double{
        return 1.0
    }

    override fun toString(): String {
        return "Circle(radius=$radius)"
    }


}