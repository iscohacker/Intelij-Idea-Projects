package Vazifa_2

class Cylinder : Circle(){
    var height : Double? = null

    fun getVolume(){
        println("Get Volume ishladi")
    }
    fun getAreea(){
        println("Get Area ishladi")

    }

    override fun toString(): String {
        return "Cylinder(height=$height)"
    }


}