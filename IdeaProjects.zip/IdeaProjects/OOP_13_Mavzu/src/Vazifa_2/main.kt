package Vazifa_2

fun main() {
    val circlee = Circle()
    println(circlee)

    val slinder = Cylinder()
    println(slinder)


}