package Vazifa_2

open class Circle {
    var radius : Double? = null
    get() = field
    var color : String? = null
    get() = field

    fun getArea(){
        println("Get Area ishladi")
    }

    override fun toString(): String {
        return "Circle(radius=$radius, color=$color)"
    }


}