package Vazifa_3

fun main() {
    val personn = Person("Iskandar","Fergana")
    println(personn)

    val stafff = Staff("Iskandar","Fergana","8-maktab",5.0)
    println(stafff)

    val studeent = Student("Iskandar","Fergana","Android",2024,5.0)
    println(studeent)
}
