package Vazifa_3

class Staff : Person{
    var school : String? = null
    get() = field
    set(value) {
        field = value
    }
    var pay : Double? = null
    get() = field
    set(value) {
        field = value
    }

    constructor(name: String?, adress: String?, school: String?, pay: Double?) : super(name, adress) {
        this.school = school
        this.pay = pay
    }

    override fun toString(): String {
        return "Staff(name=$name,adrees=$adress,school=$school, pay=$pay)"
    }


}