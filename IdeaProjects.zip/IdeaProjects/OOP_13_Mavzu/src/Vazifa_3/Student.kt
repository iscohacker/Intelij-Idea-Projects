package Vazifa_3

class Student : Person{
    var program : String? = null
    get() = field
    set(value) {
        field = value
    }
    var year : Int? = null
    get() = field
    set(value) {
        field = value
    }
    var fee : Double? = null
    get() = field
    set(value) {
        field = value
    }

    constructor(name: String?, adress: String?, program: String?, year: Int?, fee: Double?) : super(name, adress) {
        this.program = program
        this.year = year
        this.fee = fee
    }

    override fun toString(): String {
        return "Student(name=$name,adrees=$adress,program=$program, year=$year, fee=$fee)"
    }


}