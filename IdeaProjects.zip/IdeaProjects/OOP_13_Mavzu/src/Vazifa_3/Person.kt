package Vazifa_3

open class Person {
    var name : String? = null
    get() = field
    var adress : String? = null
    get() = field
    set(value) {
        field = value
    }

    constructor(name: String?, adress: String?) {
        this.name = name
        this.adress = adress
    }

    override fun toString(): String {
        return "Person(name=$name, adress=$adress)"
    }


}