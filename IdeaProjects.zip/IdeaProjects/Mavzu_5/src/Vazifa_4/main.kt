package Vazifa_4
import java.util.*

fun main() {
    //1-7 gacha bo'lgan butun sonlar berilgan.
    // Kiritilgan songa mos ravishda hafta kunlarini
    // so'zda ifodalovchi programma tuzilsin.
    // (1-Dushanba, 2-Seshanba,...)
    val kirit = Scanner(System.`in`)
    println("Hafta kunini kiriting")
    val n = kirit.nextInt()
    if (n==1){
        println("Dushanba")
    }else if (n==2){
        println("Seshabna")
    }else if (n==3){
        println("Chorshanba")
    }else if (n==4){
        println("Payshanba")
    }else if (n==5){
        println("juma")
    }else if (n==6){
        println("Shanba")
    }else if (n==7){
        println("Yakshanba")

    }else{
        println("Bunday hafta kuni yo'q")
    }
}
//creator : Iskandar Nosirov
