package Vazifa_3
import java.util.*
fun main() {
    val k = Scanner(System.`in`)
    println("Son kiriting:")
    val son = k.nextInt()
    print("")
    print(son.toString().length)
    print("")
    print("xonali")
    print("")
    if (son%2==0){
        print("")
        print("juft son")
    }else{
        print("")
        print("toq son")
    }
}
//creator : Iskandar Nosirov