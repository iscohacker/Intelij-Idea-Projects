package Vazifa_6

import java.util.*
import kotlin.system.exitProcess

fun main() {
   /*
   100 - 999 gacha oraliqdagi sonlarni so'zlarda
   ifodalovchi programma tuzilsin. Masalan: 123-"bir yuz yigirma uch"
    */
    val input = Scanner(System.`in`)
    var natija = ""
    print("Iltimos,biror son kiriting: ")
    var son = input.next()
    while (true){
        if (son[0] == '1'){
            natija = "bir yuz "
        }
        if (son[0] == '2'){
            natija = "ikki yuz "
        }
        if (son[0] == '3'){
            natija = "uch yuz "
        }
        if (son[0] == '4'){
            natija = "to'rt yuz "
        }
        if (son[0] == '5'){
            natija = "besh yuz "
        }
        if (son[0] == '6'){
            natija = "olti yuz "
        }
        if (son[0] == '7'){
            natija = "yetti yuz "
        }
        if (son[0] == '8'){
            natija = "sakkiz yuz "
        }
        if (son[0] == '9'){
            natija = "to'qqiz yuz "
        }
        val onlikSon = son.substring(1,son.toString().length-1)
        if (onlikSon == "1"){
            natija += " o'n "
        }
        if (onlikSon == "2"){
            natija += " yigirma "
        }
        if (onlikSon == "3"){
            natija += " o'ttiz "
        }
        if (onlikSon == "4"){
            natija += " qirq "
        }
        if (onlikSon == "5"){
            natija += " ellik "
        }
        if (onlikSon == "6"){
            natija += " oltmish "
        }
        if (onlikSon == "7"){
            natija += " yetmish "
        }
        if (onlikSon == "8"){
            natija += " sakson "
        }
        if (onlikSon == "9"){
            natija += " to'son "
        }
        var birlikSon = son.substring(2,son.toString().length)
        if (birlikSon == "1"){
            natija += " bir"
        }
        if (birlikSon == "2"){
            natija += " ikki"
        }
        if (birlikSon == "3"){
            natija += " uch"
        }
        if (birlikSon == "4"){
            natija += " to'rt"
        }
        if (birlikSon == "5"){
            natija += " besh"
        }
        if (birlikSon == "6"){
            natija += " olti"
        }
        if (birlikSon == "7"){
            natija += " yetti"
        }
        if (birlikSon == "8"){
            natija += " sakkiz"
        }
        if (birlikSon == "9"){
            natija += " to'qqiz"
        }
        println(natija)
        exitProcess(1)
    }
}
//creator : Iskandar Nosirov