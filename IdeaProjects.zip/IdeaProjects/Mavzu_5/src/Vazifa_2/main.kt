package Vazifa_2
import java.util.*

fun main() {
//    OX va OY koordinata o'qlarida
//    yotmaydigan nuqta berilgan.
//    Nuqta joylashgan koordinata choragi aniqlansin.
    val input = Scanner(System.`in`)
    print("Birinchi kordinatani kiriting: ")
    val son1 = input.nextInt()
    print("Ikkinchi kordinatani kiriting: ")
    val son2 = input.nextInt()
    if (son1 > 0 && son2 > 0){
        println("Siz belgilagan nuqta birinchi chorakda joylashgan")
    }
    if (son1 > 0 && son2 < 0){
        println("Siz belgilagan nuqta ikkinchi chorakda joylashgan")
    }
    if (son1 < 0 && son2 < 0){
        println("Siz belgilagan nuqta uchinchi chorakda joylashgan")
    }
    if (son1 < 0 && son2 > 0){
        println("Siz belgilagan nuqta to'rtinchi chorakda joylashgan")
    }
}
//creator : Iskandar Nosirov