package Vazifa_5
import java.util.*

fun main() {
    //Oy raqami berilgan. Shu oyda necha
    // kun borligini aniqlovchi programma tuzilsin.
    val kirit = Scanner(System.`in`)
    println("Oy raqamini kiriting:")
    val n = kirit.nextInt()
    when (n) {
        1 -> println("Yanvar 31 kundan iborat")
        2 -> println("Fevral 28 yoki 29 kundan iborat")
        3 -> println("Mart 31 kundan iborat")
        4 -> println("Aprel 30 kundan iborat")
        5 -> println("May 31 kundan iborat")
        6 -> println("Iyun 30 kundan iborat")
        7 -> println("Iyul 31 kundan iborat")
        8 -> println("Avgust 31 kundan iborat")
        9 -> println("Sentabr 30 kundan iborat")
        10 -> println("Oktabr 31 kundan iborat")
        11 -> println("Noyabr 30 kundan iborat")
        12 -> println("Dekabr 31 kundan iborat")
        else ->
            println("Afsus! Bunday oy kuni  yo'q")

    }
}
//creator : Iskandar Nosirov