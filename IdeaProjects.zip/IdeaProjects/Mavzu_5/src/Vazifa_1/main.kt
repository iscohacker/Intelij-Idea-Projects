package Vazifa_1

import java.util.*
import kotlin.math.abs

fun main() {
    val a = -3
    val b = 3
    val c = 2
    val ab = abs(a-b)
    val ac = abs(a-c)
    if (ab<ac)
        println("A nuqtaga B yaqin")
    else if (ab>ac)
        println("A nuqtaga C nuqta yaqin")
}
//creator : Iskandar Nosirov